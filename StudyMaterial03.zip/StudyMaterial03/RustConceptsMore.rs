

//_____________________________________________________________

const GLOBAL_CONSTANT_VALUE: i32 = 99;

fn play_with_constants() {
	// error: missing type for `const` item
	// const THREE_HOURS_IN_SECONDS = 60 * 60 * 3;
	 							// ^ help: provide a type for the constant: `: i32`

	// const THREE_HOURS_IN_SECONDS: i32 = 60 * 60 * 3;

	// Business Logic Wise Time Can't Be Negative
	const THREE_HOURS_IN_SECONDS: u32 = 60 * 60 * 3;

	// const THREE_HOURS_IN_SECONDS: u32 = 60 * 60 * 3;
	// error[E0428]: the name `THREE_HOURS_IN_SECONDS` is defined multiple times

	println!("Value: {THREE_HOURS_IN_SECONDS}");
	println!("Value: {GLOBAL_CONSTANT_VALUE}");

}

// Constants
// Like immutable variables, constants are values that are bound to a name and are not allowed
// to change, but there are a few diﬀerences between constants and variables.
// First, you aren’t allowed to use mut with constants. Constants aren’t just immutable by
// default—they’re always immutable. You declare constants using the const keyword instead
// of the let keyword, and the type of the value must be annotated. 

// Just know that you must always annotate the type.
// Constants can be declared in any scope, including the global scope,

// The last diﬀerence is that constants may be set only to a constant expression, 
// not the result of a value that could only be computed at runtime.

// Statements and Expressions
// Function bodies are made up of a series of statements optionally ending in an expression.
// Because Rust is an expression-based language,
// this is an important distinction to understand. Other languages don’t have the same
// distinctions


//_____________________________________________________________

// Primitives
// Rust provides access to a wide variety of primitives. A sample includes:

// Scalar Types
// Signed integers: i8, i16, i32, i64, i128 and isize (pointer size)
// Unsigned integers: u8, u16, u32, u64, u128 and usize (pointer size)

// Floating point: f32, f64

// char Unicode scalar values like 'a', 'α' and '∞' (4 bytes each)
// bool either true or false

// The unit type (), whose only possible value is an empty tuple: ()
// 		Despite the value of a unit type being a tuple, 
// 		it is not considered a compound type because it does not contain multiple values.

// Compound Types
// Arrays like [1, 2, 3]
// Tuples like (1, true)

// Variables can always be type annotated. 
// Numbers may additionally be annotated via a suffix or by default. 
// Integers default to i32 and floats to f64. Note that Rust can also infer types from context.

#[allow(unused)]
fn play_with_types_again() {
    // Variables can be type annotated.
    let logical: bool = true;

    let a_float: f64 = 1.0;   // Regular annotation
    let an_integer   = 5i32;  // Suffix annotation
    let an_integer_again: i32   = 5;  // Suffix annotation

    // Or a default will be used.
    let default_float   = 3.0; // `f64`
    let default_integer = 7;   // `i32`

    // A type can also be inferred from context.
    let mut inferred_type = 12; // Type i64 is inferred from another line.    
    // Bring Safety In Code Rust Compiler Does Usage Analysis
    inferred_type = 4294967296i64;

    // inferred_type = 4294967296;
    // inferred_type = 4294967296.999f32;
    // ^^^^^^^^^^^^^^^^^ expected integer, found `f32`

    // error: literal out of range for `i32`
       // = note: the literal `4294967296` does not fit into the type `i32` whose range is `-2147483648..=2147483647`
	   // = help: consider using the type `i64` instead

    println!("inferred_type Value: {inferred_type} ");

    // A mutable variable's value can be changed.
    let mut mutable = 12; // Mutable `i32`
    mutable = 21;

    // Error! The type of a variable can't be changed.
    // mutable = true;

    // Variables can be overwritten with shadowing.
    let mutable = true;

    /* Compound types - Array and Tuple */

    // Array signature consists of Type T and length as [T; length].
    let my_array: [i32; 5] = [1, 2, 3, 4, 5];

    // Tuple is a collection of values of different types 
    // and is constructed using parentheses ().
    let my_tuple = (5u32, 1u8, true, -5.04f32);

	// 	RHS Inferred Type Is i32, 
	//	LHS Annotated Type Is i64
	//		As LHS Type Is Annotated By Programmer As i64 Compiler Will Be i64 With green
	//		And Type Cast Value 4 To i64 At Initialisation Time
    let mut green:i64 = 4 ; 
    println!("green Value: {}",green );
    println!("green Value: {green}" );

    // Type Of green Is i64
    // green = 9_223_372_036_854_775_900
	// ERROR: the literal `9_223_372_036_854_775_900` does not fit into the type  `i64` 
	//		whose range is `-9223372036854775808..=9223372036854775807`
}

//_____________________________________________________________

fn play_controls() {
    let number = 3;

    if number < 5 {
        println!("condition was true");
    } else {
        println!("condition was false");
    }

    let number = 6;

    if number % 4 == 0 {
        println!("number is divisible by 4");
    } else if number % 3 == 0 {
        println!("number is divisible by 3");
    } else if number % 2 == 0 {
        println!("number is divisible by 2");
    } else {
        println!("number is not divisible by 4, 3, or 2");
    }

    let mut number = 3;

    while number != 0 {
        println!("{number}!");

        number -= 1;
    }

    println!("LIFTOFF!!!");

    for number in (1..4).rev() {
        println!("{number}!");
    }
    println!("LIFTOFF!!!");
}


//_____________________________________________________________

fn play_with_overflow_underflow() {
	let a : i8 = 127;
	let b : i8 = 10;


    // IN RUST:: Following Overflow/Underflow Checks Generated In Debug Mode

    // if (a > 0 && b > INT_MAX - a) {
    //     printf("Overflow Happening");
    //     return
    // } else if (a < 0 && b < INT_MIN - a) {
    //     printf("Overflow Happening");
    //     return 
    // }

	let c = a + b;
		// error: this arithmetic operation will overflow

	println!("Value: {c}" );

	let _d: i8 = 200;
	// 	error: literal out of range for `i8`
}

//_____________________________________________________________


// integer overflow
// will occur, which can result in one of two behaviors. When you’re compiling in debug
// mode, Rust includes checks for integer overflow that cause your program to panic at
// runtime if this behavior occurs. Rust uses the term panicking when a program exits

// When you’re compiling in release mode with the --release flag, 
//      Rust does not include checks for integer overflow that cause panics. 
//      Instead, if overflow occurs, Rust performs two’s complement wrapping.

// To explicitly handle the possibility of overflow, 
//  you can use these families of methods
//      provided by the standard library for primitive numeric types:

// Relying on integer overflow’s wrapping behavior is considered an error.

//      Wrap in all modes with the wrapping_* methods, such as wrapping_add
//      Return the None value if there is overflow with the checked_* methods
//      Return the value and a boolean indicating 
//            whether there was overflow with the overflowing_* methods
//      Saturate at the value’s minimum or maximum values with saturating_* methods


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_constants");
	play_with_constants();

	println!("\n\nFunction: play_with_types_again");
	play_with_types_again();

	println!("\n\nFunction: play_controls");
	play_controls();

	println!("\n\nFunction: play_with_overflow_underflow");
	play_with_overflow_underflow();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

