
//_____________________________________________________________

fn play_with_scope() { // Outside Scope
	// Allocated Object At Stack
	let greeting = "Good Evening!";

	println!("Hey: {greeting}");

	// Allocated Object At Heap
	let hello = String::from("Hello Jimmy!!!");
	println!("Hey: {hello}");

	{ // Local/Inside Scope
		let hello = "Hello!";
		println!("Hey: {hello}");
	} // Local hello Dropped

	println!("Hey: {hello}");

	let hello = "Good Afternoon!!!";
	println!("Hey: {hello}");
}

//_____________________________________________________________

// In Rust Every Object Going To Have ONLY ONE OWNER

fn play_with_scope_again() { // Outside Scope
	// Allocated Object At Stack
	// let greeting: String = "Good Evening!";
	// ------   ^^^^^^^^^^^^^^^ expected `String`, found `&str`
	let greeting = "Good Evening!";

	println!("Hey: {greeting}");

	// Object Assignment Doing Copy Semantics
	//		Hence One Duplicate Copy Of The Object Created
	// 		hello And greeting Are Owners Of Different Object
	let hello = greeting; // Copy Semantics
	println!("Hey: {hello}");
	println!("Hey: {greeting}");

	// Allocated Object At Heap
	// greeting1 Is A Reference Which Is Owner Of Object "Hello Jimmy"
	let greeting1: String = String::from("Hello Jimmy!!!");
	 // --------- move occurs because `greeting1` has type `String`, 
	 //			  which does not implement the `Copy` trait
	println!("Hey: {greeting1}");

	// Reference Assignment Doing Move Semantics
	// 		Along with Shifting/Moving Ownership To hello1
	//		hello1 Is Now Onwer Of Object "Hello Jimmy"
	//		greeting1 Is Now No More Owner Of Object "Hello Jimmy"
	let hello1 = greeting1; // Move Semantics
	// 	error[E0382]: borrow of moved value: `greeting1`

	println!("Hey: {hello1}");
	// error[E0382]: borrow of moved value: `greeting1`
	// println!("Hey: {greeting1}");
			// ^^^^^^^^^ value borrowed here after move

	//___________________________________

	let n1 = 99;
	// Object Getting Copied
	let n2 = n1; // Copy Semantics

	println!("Values : {} {}", n1, n2 );

	// Here are some of the types that implement Copy:
	// All the integer types, such as u32.
	// The Boolean type, bool, with values true and false.
	// All the floating point types, such as f64.
	// The character type, char.
	// Tuples, if they only contain types that also implement Copy. 
	// 		For example, (i32, i32) implements Copy, 
	// 		but (i32, String) does not.

	//___________________________________
	// Cloning Example

	let something1 = String::from("BMW Techians");
	println!("Hey: {something1}");
	
	// let something2 = something1 // Move Semantics
	// println!("Hey: {something1}");
	// println!("Hey: {something2}");

	// One More String Object Created In Heap
	//		something3 Will Be Referance As Well As Owner Of This New Object
	let something3 = something1.clone(); // Deep Copy
	println!("Hey: {something1}");
	println!("Hey: {something3}");
}

//_____________________________________________________________

 // ^^^^^^ this parameter takes ownership of the value
 //		Move Semantics :: Ownership Moved To Parameter i.e. some_string
fn play_with_greeting( some_string: String ) {
	println!("Inside :: String Value: {some_string}");
}

fn play_with_number( some_number: i32 ) {
	println!("Inside :: Number Value: {some_number}");
}

fn play_with_function_parameters() {
	let greeting = String::from("Good Afternoon!!!");

	println!("Before Function Call String Value: {greeting}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Move Symantic Is Applied Here
	//		Hence Ownership Shifted To some_string
	//		some_string Is Owner Of The String Object "Good Evening!!!"
	play_with_greeting( greeting ); // Move Semantics
	// println!("After  Function Call String Value: {greeting}");
 	// 				^^^^^^^^ value borrowed here after move

 	let number = 999;
	println!("Before Function Call Number Value: {number}");
	//	Copy Symantic Is Applied Here
	//		Duplicate Copy Of Object Created 
	//		And Assigned To Parameter some_number
	play_with_number( number ); // Copy Semantics
	println!("After  Function Call String Value: {number}");
}


//_____________________________________________________________

 // ^^^^^^ this parameter takes ownership of the value
 //		Move Semantics :: Ownership Moved To Parameter i.e. some_string
fn play_with_greeting_again( some_string: String ) -> String {
	println!("Inside :: String Value: {some_string}");

	// Last Expression Is Return Value Function
	//	Move Semantics
	//		some_string Ownership Is Shifted Back To The Caller
	some_string // Expression
}

fn say_greeting() -> String {
	// Object Allocated At Heap
	let greeting = String::from("Good Afternoon!!!");

	// Last Expression Is Return Value Function
	//	Move Semantics
	//		greeting Ownership Is Shifted To The Caller
	greeting // Expression
}


fn play_with_function_parameters_again() {
	let greeting = String::from("Good Afternoon!!!");

	println!("Before Function Call String Value: {greeting}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Move Symantic Is Applied Here
	//		Hence Ownership Shifted To some_string
	//		some_string Is Owner Of The String Object "Good Evening!!!"
	// play_with_greeting_again( greeting ); // Move Semantics
	// let greeting_back = play_with_greeting_again( greeting ); // Move Semantics
	// println!("After  Function Call String Value: {greeting_back}");
 	// 				^^^^^^^^ value borrowed here after move

 	// Use The Already Existing Domain Name
 	//		Use Case Of Shadowing
	let greeting = play_with_greeting_again( greeting ); // Move Semantics
	println!("After  Function Call String Value: {greeting}");

	say_greeting();

	// Shifted The Returned Object Ownership To greet
	let greet = say_greeting();
	println!("After  Function Call String Value: {greet}");
}

//_____________________________________________________________

fn calculate_length( some_string: &String ) -> usize {
	// some_string = &String::from("Good Morning Once Again!!!");
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ cannot assign to immutable argument
	some_string.len()
}

fn play_with_passing_references() {
	// Ownwership Of This Objeect Lies With greeting
	//		greeting Is The Owner Of Object "Good Morning!!!"

	// {
	let greeting = String::from("Good Morning!!!");
	// }

	println!("String Value: {greeting}");
	// Borrow Semantics
	//		Passing Reference Of greeting
	//		Ownership Is Not Moved/Shfited

	//		greeting Is The Owner Of The Object "Good Morning!!!""
	//		Passing &greeting Means Passing Reference Only But Not Shifting Ownership
	//		&greeting Is A Reference : It's A Safe Pointer
	let length = calculate_length( &greeting ); // Borrow Semantic
	println!("String Length: {length}");

	// Because Ownership Is Not Moved To calculate_length Function
	//		greeting As Owner Is Still Valid Hence You Can Assess Object Using It
	println!("String Value: {greeting}");

	//		greeting1 Is The Owner Of Object "Good Morning!!!"
	let greeting1 = String::from("Good Morning!!!");
	println!("String Value: {greeting1}");

	let reference = &greeting1; // Borrow Semantics
	println!("String Value: {greeting1}");
	println!("String Value: {reference}");
}

//_____________________________________________________________


//_____________________________________________________________
//
// +++++  EXPERIMENT BELOW CODE AND RAISE YOUR HANDS MOMENT DONE!!!
//_____________________________________________________________


//______________________________________________________________

 // Instead, we can provide a Rust reference to the String value. 
 //     A Rust reference is like a pointer in that it’s an address 
 //		we can follow to access the data stored at that address; 
 //     that data is owned by some other variable. 
 
 //    	UNLIKE a Pointer, a reference is guaranteed to point 
 //     to a valid value of a particular type for the life of 
 //     that reference.

//______________________________________________________________

// When functions have references as parameters instead 
//      of the actual values, we won’t need to return 
//      the values in order to give back ownership, 
//      because we never had shifted ownership.

// We call the action of creating a reference borrowing. 

//_____________________________________________________________

// help: consider making this binding mutable
// fn change_function( some_string : &str ) -> String {
//    // |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ cannot assign to immutable argument

// fn change_function( mut some_string : &str ) -> String {
fn change_function( mut some_string : &str ) -> &str {
	// some_string Carries Duplicate Copy Of The "Hello!!!"
	// 		Allocated At Stack "Hello!!!";	
	println!("Inside Function :: String Value: {some_string}");

	some_string = "How are you doing?";
	println!("Inside Function :: String Value: {some_string}");

	// Return Value Of The Function As Follows:
	// some_string.to_string() // Expression
	some_string // Expression
}


// fn change_function_again( some_string : String ) -> String {
// error[E0596]: cannot borrow `some_string` as mutable, as it is not declared as mutable
// 		help: consider changing this to be mutable
fn change_function_again( mut some_string : String ) -> String {
	// some_string Takes Ownership Using Move Semantics
	println!("Inside Function :: String Value: {some_string}");

	some_string.push_str( " Gentleman!!!" );
	println!("Inside Function :: String Value: {some_string}");

	// Return Value Of The Function As Follows:
	//		change_function_again Shifting/Moving Ownership Back To Caller
	some_string // Expression
}


// error[E0596]: cannot borrow `*some_string` as mutable, as it is behind a `&` reference
// 	some_string.push_str( " Gentleman!!!" );
//     |     ^^^^^^^^^^^ `some_string` is a `&` reference, so it cannot be borrowed as mutable

// Following Two Lines Of Code Are Equivalent
// fn change_function_once_again( some_string : &String ) -> () {
// fn change_function_once_again( some_string : &String ) {


fn change_function_once_again( some_string : &mut String ) {
	println!("Inside Function :: String Value: {some_string}");
	some_string.push_str( " Gentleman!!!" );
	println!("Inside Function :: String Value: {some_string}");
	// Rust By Default Returns Unit Value () Of Unit Type ()
	// () 
}


fn play_with_change_functions() {
	//_________________________________________________
	// Copy Semantic Example
	// This Object Allocated At Stack "Hello!!!";	
	let hello = "Hello!!!";

	println!("Before Change Call:: Value : {hello}");
	change_function( hello ); // Copy Semantics

	println!("After  Change Call:: Value : {hello}");

	//_________________________________________________
	// Move Semantic Example
	// This Object Allocated At Heap  "Good Morning!!!";	
	
	let greeting = String::from("Good Morning!!!");
	println!("Before Change Call:: Value : {greeting}");

	// Ownership Already Shifted/Moved To some_string Parameter
	//		greeting Is No More Owner 
	//		Hence greeting No More Valid After Call To Following Function
	//		Though change_function_again Shifting/Moving Ownership Back To Caller
	//			But Here Caller Is Not Taking Ownership 
	// change_function_again( greeting ); // Move Semantics


	// println!("After  Change Call:: Value : {greeting}");
	// Shifting/Moving Ownership Back To Caller
	//		Here Caller Is Taking Ownership and Assigned Owner Is greeting 
	let greeting = change_function_again( greeting ); // Move Semantics
	println!("After  Change Call:: Value : {greeting}");

	//_________________________________________________
	// Borrow Semantic Example
	// This Object Allocated At Heap  "Good Morning!!!";	

	// let greeting_again = String::from("Good Morning!!!");
	// let greeting_again: String = String::from("Good Morning!!!");
	let mut greeting_again = String::from("Good Morning!!!");

	println!("Before Change Call:: Value : {greeting_again}");

	// change_function_once_again( &greeting_again ); // Borrow Semantics
	 // --------------------------  ^^^^^^^^^^^^^^^ types differ in mutability

	change_function_once_again( &mut greeting_again ); // Borrow Semantics
	println!("After  Change Call:: Value : {greeting_again}");
}

//_____________________________________________________________


//_____________________________________________________________
//
// +++++  EXPERIMENT BELOW CODE AND RAISE YOUR HANDS MOMENT DONE!!!
//_____________________________________________________________


fn play_with_mutable_references() {

	//__________________________________________	
	// Object Is "Hello" Allocated At Heap
	//		Owner Of "Hello" Object s
	let s = String::from("Hello!");
	println!("Value: {}", s);

	// Due To Borrow Semantics Ownership Is Not Moved/Shifted
	//	r1 Is Borrowing Of "Hello" Object
	//		"Hello" Object Have Two Aliases	
	let r1 = &s; // Borrow Semantics
	println!("Value: {}", s); 
	println!("Value: {}", r1);

	//__________________________________________	
	// Object Is "Hello" Allocated At Stack
	//		Owner Of "Hello" Object ss
	let ss = "Hello!!!";
	println!("Value: {}", ss);

	// Due To Borrow Semantics Ownership Is Not Moved/Shifted
	//	rr1 Is Borrowing Of "Hello" Object
	//		"Hello" Object Have Two Aliases	
	let rr1 = &ss; // Borrow Semantics
	println!("Value: {}", ss); 
	println!("Value: {}", rr1);

	//__________________________________________	

	// Object Is "Hello" Allocated At Heap
	//		Owner Of "Hello" Object o
	let o = String::from("Hello!");
	println!("Value: {}", o);

	// Due To Borrow Semantics Ownership Is Not Moved/Shifted
	//		"Hello" Object Have Two Aliases	
	let r2 = &o; // Borrow Semantics
	let r3 = &o; // Borrow Semantics
	let r4 = &o; // Borrow Semantics
	println!("Value: {}", o); 
	println!("Value: {}", r2);
	println!("Value: {}", r3);
	println!("Value: {}", r4);

	//__________________________________________	

	// Mutable references have one big restriction: 
    // 		if you have a mutable reference to a value
    //  	It Must Be Only One Mutable Reference

	// Object Is "Hello" Allocated At Heap
	//		Owner Of "Hello" Object oo

	// let oo = String::from("Hello!");
	// error[E0596]: cannot borrow `oo` as mutable, as it is not declared as mutable
	// |     let r5 = &mut oo; // Borrow Semantics
    // |              ^^^^^^^ cannot borrow as mutable

	let mut oo = String::from("Hello!");
	println!("Value: {}", oo);

	// Due To Borrow Semantics Ownership Is Not Moved/Shifted
	//		"Hello" Object Have Two Aliases	
	let r5 = &mut oo; // Borrow Semantics
	// let r6 = &oo; // Borrow Semantics
	// let r7 = &oo; // Borrow Semantics
	println!("Value: {}", r5);

	// error[E0502]: cannot borrow `oo` as immutable because it is also borrowed as mutable
	// println!("Value: {}", r6);
	// println!("Value: {}", r7);


	// The restriction preventing multiple mutable references 
	//		to the same data at the same time allows for mutation 
	//		but in a very controlled fashion. 

	// A data race is similar to a race condition and 
	//		happens when these three behaviors occur:
			//  1. Two or more pointers access the same data at the same time.
			//  2. At least one of the pointers is being used to write to the data.
			//  3. There’s no mechanism being used to synchronize access to the data.

	//__________________________________________	

	// let tt = String::from("Hello!");
	let mut tt = String::from("Hello!");
	println!("Value: {}", tt);

	tt.push_str(" Jimmy!!!");
	// let _mr1 = &mut tt; // Borrow Semantics
	// let _mr2 = &mut tt; // Borrow Semantics

	println!("Value: {}", tt);
	// println!("Value: {}", mr1);
	// println!("Value: {}", mr2);

	//__________________________________________	

	// let sss = String::from("Hello!");
	let mut sss = String::from("Hello!");
	println!("Value: {}", sss);

	let ir1 = &sss;
	let ir2 = &sss;
	let ir3 = &sss;

	// let mr4 = &mut sss;
	 // ^^^^^^^^ mutable borrow occurs here
	println!("Value: {} {} {}", ir1, ir2, ir3 );
	// println!("Value: {}", mr4);

    // The ability of the compiler to tell that a reference is no 
    // longer being used at a point before the end of the scope 
    //	is called Non-Lexical Lifetimes (NLL for short), 

	let mr4 = &mut sss;
	println!("Value: {}", mr4);


	//__________________________________________	

	// let sss = String::from("Hello!");
	let mut ttt = String::from("Hello!");
	println!("Value: {}", sss);
	
	{
		let ir1 = &ttt;
		let ir2 = &ttt;
		let ir3 = &ttt;
		println!("Value: {} {} {}", ir1, ir2, ir3 );
	}

    // The ability of the compiler to tell that a reference is no 
    // longer being used at a point before the end of the scope 
    //	is called Non-Lexical Lifetimes (NLL for short), 

    // Code Sample 01
	let mr5 = &mut ttt;
	println!("Value: {}", mr5);

	let mr6 = &mut ttt;
	println!("Value: {}", mr6);

	// For Above Lines Of Code Sample 01 Eqivalent To Following
	// {	
	// 		let mr5 = &mut ttt;
	// 		println!("Value: {}", mr5);
	// }

	// {	
	// 		let mr6 = &mut ttt;
	// 		println!("Value: {}", mr6);
	// }


    // Code Sample 02
	let mr5 = &mut ttt;
	// let mr6 = &mut ttt;

	println!("Value: {}", mr5);
	// println!("Value: {}", mr6);

	// For Above Lines Of Code Sample 02 Eqivalent To Following
	{
		let mr5 = &mut ttt;
		// let mr6 = &mut ttt;

		println!("Value: {}", mr5);
		// println!("Value: {}", mr6);
	}
}

// The Rules of References In Same Scope
// 		1.	At any given time, you can have either one mutable reference 
// 		2. 	or any number of immutable references.
// 		3.	References must always be valid.


//_____________________________________________________________
//_____________________________________________________________

fn play_with_mutability() {

	// let hello = String::from("Hello");
	let mut hello = String::from("Hello");

    // let refer = &hello; // Borrow Semantic
    let refer = &mut hello; // Borrow Semantic
	// error[E0596]: cannot borrow `hello` as mutable, as it is not declared as mutable

    // println!("Object: {}", refer);
    // println!("Object: {}", hello);

    // println!("Object: {}", hello);
    // println!("Object: {}", refer);
    
    refer.push_str(" Changed!!!");
    hello.push_str(" Once More!!!");

    // hello.push_str(" Once More!!!");
    // refer.push_str(" Changed!!!");

    // ^^^^^ `refer` is a `&` reference, so it cannot be borrowed as mutable
	//		help: consider changing this to be a mutable reference

    // println!("Object: {}", refer);
    println!("Object: {}", hello);    
}

//_____________________________________________________________
//
// Dangling Pointers
//_____________________________________________________________

 // `let` cannot be used for global variables
// let something_global = 99;

// error[E0106]: missing lifetime specifier
// fn dangling_pointer() -> &String {
//		"Good Afternoon!" Allocated At Stack
// 		let hello = "Good Afternoon!!!";
// 		println!("Inside Hello: {hello}");

// 		return &hello
// }

fn dangling_pointer() -> String {
//		"Good Afternoon!" Allocated At Heap
//				Owner Is hello
		let hello = String::from("Good Afternoon!!!");
		println!("Inside Hello: {hello}");

		// Return Object As Well Moving/Shifting Ownership
		return hello
} // Owner Is Alive Till Scope Ends


// error[E0106]: missing lifetime specifier
// fn dangling_pointer_again() -> &String {
// //		"Good Afternoon!" Allocated At Heap
// //				Owner Is hello
// 		let hello = String::from("Good Afternoon!!!");
// 		println!("Inside Hello: {hello}");

// 		// Return Object Reference 
// 		//		Returning Borrrow But Not Moving/Shifitng Ownership
// 		return &hello
// } // Owner Is Alive Till Scope Ends


fn play_with_danglings() {
	// Caller Taking Ownership Of Returned Object
	//		Owner Is something
	let something = dangling_pointer();
	println!("Value: {something}");


	// let something_again = dangling_pointer_again();
	// println!("Value: {something_again}");
}


// Dangling References
// 		In languages with pointers, it’s easy to erroneously 
//		create a dangling pointer--a pointer that references a 
//		location in memory that may have been given to someone else
//		--by freeing some memory while preserving a pointer to that memory. 

// IN RUST LANGUAGE
//		by contrast, the compiler guarantees that references 
//		will never be dangling references: if you have a reference 
//		to some data, the compiler will ensure that the data will 
//		not go out of scope before the reference to the data does.


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_scope");
	play_with_scope();

	println!("\n\nFunction: play_with_scope_again");
	play_with_scope_again();

	println!("\n\nFunction: play_with_function_parameters");
	play_with_function_parameters();

	println!("\n\nFunction: play_with_function_parameters_again");
	play_with_function_parameters_again();

	println!("\n\nFunction: play_with_passing_references");
	play_with_passing_references();

	println!("\n\nFunction: play_with_change_functions");
	play_with_change_functions();

	println!("\n\nFunction: play_with_mutability");
	play_with_mutability();

	println!("\n\nFunction: play_with_mutable_references");
	play_with_mutable_references();

	println!("\n\nFunction: play_with_mutability");
	play_with_mutability();

	println!("\n\nFunction: play_with_danglings");
	play_with_danglings();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

