
int
sum (int a, int b)
{
  long a_ = a;
  long b_ = b;
  long sum = a_ + b_;
  if (sum > INT_MAX)
    {
      printf ("Cant Calculate valid sum\n");
      return 0;
    }
  return sum;
}


int
sum (int a, int b)
{
  if ((b > 0 && a > INT_MAX - b) || (b < 0 && a < INT_MIN - b))
    {
      printf ("Can't Calculate Valid Sum For Given a And b Values\n");
      return 0;
    }
  return a + b;
}

int
sum (int a, int b)
{

  long long result = (long long) a + b;

  if (result > INT_MAX || result < INT_MIN)
    {

      printf ("Warning: overflow!\n");

    }

  return (int) result;

}


int
sum (int a, int b)
{
  int carry = 0;
  str final_result = "";
  while (a > 0 && b > 0)
    {
      int tempa = a % 10;
      int tempb = b % 10;
      a /= 10;
      b /= 10;
      int sum = tempa + tempb + carry;
      carry = sum / 10;
      final_result = to_string (sum % 10) + final_result;
    }
  while (a > 0)
    {
      int tempa = a % 10;
      a /= 10;
      int sum = tempa + carry;
      carry = sum / 10;
      final_result = to_string (sum % 10) + final_result;
    }
  while (b > 0)
    {
      int tempb = b % 10;
      b /= 10;
      int sum = tempb + carry;
      carry = sum / 10;
      final_result = (sum % 10) + final_result;
    }
  if carry
    >0
    {
      final_result = to_string (carry) + final_result;
    }
  return final_result;
}

int
sum (int a, int b)
{

  if ((b > 0 && a > INT_MAX - b) || (b < 0 && a < INT_MIN - b))
    {

      printf ("Can't calculate valid sum for given a and b values\n");

      return 0;

    }

  return a + b;

}


int
sum (int a, int b)
{

  if ((a > INT_MAX - b) || (a < INT_MIN - b))
    {
      printf ("Can't calculate valid sum for given a and b values\n");
      return -1;
    }
  return a + b;

}

int
sum (int a, int b)
{
  long long result = a + b;
  if (result > INT_MAX || result < INT_MIN)
    {
      printf ("cant calculate");
      return -1;
    }
  return (int) result;
}


int
sum (int a, int b)
{

  long long r = a + b;

  if (r > max_int || r < min_int)
    print ("overflow");

  return a + b;

}

int
sum (int a, int b)
{

  int result;

  if (__builtin_add_overflow (a, b, &result))
    {

      printf ("Can't calculate valid sum for a = %d and b = %d\n", a, b);

      return 0;

    }

  return result;

}

int
sum (int a, int b)
{

  if ((a > 0 && b > INT_MAX - a) || (a < 0 && b < INT_MIN - a))

    {

      printf ("Not possible\n");

      return 0;

    }

  return a + b;

}
