
//_____________________________________________________________
/*
// In Unix/Linux/Mac OSX/Windows
1. Save Code in Hello.rs
2. Make Directory Current In Which You Save Hello.rs
3. To Compile
		rustc Hello.rs
		It Will Generate Hello Executable

		rustc Hello.rs -o hello
4. To Run
		./Hello
*/

//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("Hello World!!!");
	println!("Welcome to Rust Programming....");
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

