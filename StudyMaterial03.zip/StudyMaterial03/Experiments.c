
#include <stdio.h>

//_____________________________________________________________

void playWithTypes() {
	int number = 9;

	printf("\nValue: %d", number);
	number =  999;
	printf("\nValue: %d", number);

	int numberAgain;
	printf("\nValue: %d", numberAgain);

	int condition = -10;
	// int number1 = if (condition) { 55; } else { 99; }
	// printf("\nValue: %d", number1);	

	// In C/C++
	//		Expression Can Be Anything Which Evaluated To int Value
	//		Non-Zero int Value Treated As True
	//		Zero int Value Treated As False

	// if ( Expression ) {} else { }
	
	if (condition) { 55; } else { 99; }


	int a = 10;
	// int a = 20; Compilation Error

	printf("\nValue: %d", a);
	{ // Nested Scope 1

		// Nested Scope 1 Will Shadow Outer Scope
		// Hence Local Variable Definiton Always Takes Precedence
		int a = 11;
		printf("\nValue: %d", a);
		
		{ // Nested Scope 2
			// Nested Scope 2 Will Shadow Nested Scope 1 Outer Scope
			// Hence Local Variable Definiton Always Takes Precedence
			int a  = 999;
			printf("\nValue: %d", a);

		}
		printf("\nValue: %d", a);

	}
	printf("\nValue: %d", a);
}


//_____________________________________________________________

// BAD DESIGN
int sum( int a, int b ) {
	return a + b;
}

// BAD DESIGN
// long sum( int a, int b ) {
// 	return a + b;
// }

// BAD DESIGN
// long long sum( long a, long b ) {
// 	return a + b;
// }

// BAD DESIGN
// long long sum( long long a, long long b ) {
// 	return a + b;
// }

void playWithSum() {
	int a = 2147483647;
	int b = 111;

	int result = 0;

	result = sum(a, b);
	printf("\nResult : %d", result);
}

// Function: playWithSum
// Result : -2147483538

//_____________________________________________________________

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

int main() {
	printf("\n\nFunction: playWithTypes");
	playWithTypes();

	printf("\n\nFunction: playWithSum");
	playWithSum();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

