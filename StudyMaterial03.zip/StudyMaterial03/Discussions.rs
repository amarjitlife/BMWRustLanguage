___________________________________________________________________________________
___________________________________________________________________________________

Write Following sum Function In C
	Function Should Return Valid Arithematic Integer Sum
	Or Print Can't Calculate Valid Sum For Given a And b Values

	int sum( int a, int b )


Design 01
	int sun( int a, int b ) {
		return a + b;
	}

Design 02
	signed long sun( int a, int b ) {
		return a + b;
	}


Design 03

//_______________________________________________

// Function Can Return Only 1 Value
//		Either Return Valid Result Or Error Code

int sum(int a, int b, int *error) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        *error = 1; // overflow or underflow
    }
    
    int result = a + b;
    *error = 0;
    return result; 
}

int sum(int a, int b, int *result) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        return 0; // overflow or underflow
    }
    
    *result = a + b;
    return 1; // success
}


___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________


