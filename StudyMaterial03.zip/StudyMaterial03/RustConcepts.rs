
use std::io;

//_____________________________________________________________
/*
// In Unix/Linux/Mac OSX/Windows
1. Save Code in Hello.rs
2. Make Directory Current In Which You Save Hello.rs
3. To Compile
		rustc Hello.rs
		It Will Generate Hello Executable

		rustc Hello.rs -o hello
4. To Run
		./Hello
*/

//_____________________________________________________________
//_____________________________________________________________

// fn helloWorld() {
// warning: function `helloWorld` should have a snake case name
//   --> RustConcepts.rs:19:4
//    |
// 19 | fn helloWorld() {
//    |    ^^^^^^^^^^ help: convert the identifier to snake case: `hello_world`

fn hello_world() {
	println!("Hello World!!!");
	println!("Welcome to Rust Programming....");
}

//_____________________________________________________________

// Design Principle
//		Design Towards Immutabiliity Rather Than Mutablity

fn play_with_mutability() {
	// What Is Type Of number?
	// In Rust/C++/C/Java
	// Two Step Process Happens At Compile Time
	//		1. Type Inferrencing Will Happnes From RHS Value
	//		2. Type Binding : Inferred Type Is Binded With LHS Value

	// In Python/Objective-C/JavaScript/Ruby
	// Two Step Process Happens At RunTime
	//		1. Type Inferrencing Will Happnes From RHS Value
	//		2. Type Binding : Inferred Type Is Binded With LHS Value

	let number = 10; // i32

	println!("Value: {number}");
	// number = 999;
// ^^^^^^^^^^^^ cannot assign twice to immutable variable
	// println!("Value: {number}");	

	// Two Step Process
	//		1. Type Inferrencing Will Happnes From RHS Value
	//		2. Type Binding : Inferred Type Is Binded With LHS Value
	let condition = true;
	println!("Value: {condition}");

	// let something;
	// 		error[E0282]: type annotations needed

	// Type Annotation Or Initial Value
	// warning: variable does not need to be mutable
	// let mut something: i32;

	let something: i32;
	// println!("Value: {something}");
	// 		error[E0381]: used binding `something` isn't initialized

	something = 999;
	println!("Value: {something}");

	// something = "Good Morning!";
	// 	error[E0308]: mismatched types
	// ^^^^^^^^^^^^^^^ expected `i32`, found `&str`
	// println!("Value: {something}");

	// Design Practice
	//		Never Create A Dead Code
	#[allow(unused_variables)]
	let something_again = 99;
}

//_____________________________________________________________

// #[allow(unused)]
fn play_with_if_else() {
	let condition = true;
	
	// Expression Is A Statement Having Value
	// Why Rust Allows if-else Construct Usage Like As Follows:
	// In Rust
	//		if-else Construct Is An Expression
	
	// In C/C++/Java
	//		if-else Construct Is A Statement
	// What Is The Type Of number?
	// Two Step Process
	//		1. Type Inferrencing Will Happnes From RHS Value
	//				Hence if-else Construct Have Type i32
	//		2. Type Binding : Inferred Type Is Binded With LHS Value
	//				Hence number Type Will Be i32

	let number = if condition { 55 } else { 66 };
	println!("Value: {number}");	

	// let number_again = if condition { 55 } else { "India" };
	// error[E0308]: `if` and `else` have incompatible types
	// println!("Value: {number_again}");	

	// In Rust
	//		Ending with ; Is A Statement
	//		Ending without ; Is An Expression
	// In Rust Expression Is Last In Each Block { }
	//		Expression Value Will Become Value Of Block
	// let condition = true;
	let number_again = if condition {
		// _ means Tempoary Variable Variable To Be Descarded
		let _ = 5 + 10; 	// Ending With ; Is A Statement
		let x = 100 + 200; 	// Statement

		// let y = x + _; 
		// error: in expressions, `_` can only be used on the left-hand side of an assignment

		// 99 + 88;
		// ^^^^^^^ the arithmetic operation produces a value
		let _ = 99 + 88;

		x + 300 + 900 // Expression
	} else {
		let _ = 6 - 10; //Statement
		111 + 222 // Expression 
	};

	println!("Value: {number_again}");

	// if ( Expression ) {} else { }
	// In C/C++
	//		Expression Can Be Anything Which Evaluated To int Value
	//			int Expression
	//		Non-Zero int Value Treated As True
	//		Zero int Value Treated As False

	// In Rust
	//		Expression Can Be Anything Which Evaluated To Bool Value of Bool Type
	//			Boolean Expression	

	let condition_again = -10;
	// if condition_again { 88; } else { 99; }	
	// // ^^^^^^^^^^^^^^^ expected `bool`, found integer

	if condition_again == -10 { 88; } else { 99; }	
	// ^^^^^^^^^^^^^^^ expected `bool`, found integer


	// if-else Expression Will Always Return Value
	//	By Default
	//		Unit Value () Of Unit Type ()
	let something_again  = if condition_again == -10 { 
		println!("If Block Executed");
	} else {
		println!("Else Block Executed");
	};

	println!("Value: {:?}", something_again);
}

//_____________________________________________________________

// Design Practice
//		Avoid Global Variables Even if Language Allows It

// let global_guess = "Ding Ding";
// let global_guess = "Ting Ting";
 // ^^^
 //    | |
 //    | `let` cannot be used for global variables
 //    | help: consider using `static` or `const` instead of `let`

fn play_with_shadowing() {
	// In Rust
	//		Using let You Define The Immutable Variable
	//		Variables Can Be Shadowed In Same Scope
	let guess = "Good Evening!!";
	println!("Value : {guess}");

	// Shadowing Previous Definition
	let guess = "Good Afternoon!!";
	println!("Value : {guess}");

	let guess = 11;
	println!("Value : {guess}");

	// Shadowing Use Case
	//		Switching Between Mutability and Immutability
	//		Mutability Should Be As Local As Possible
	let mut guess = 11;
	println!("Value : {guess}");

	guess = 999;
	println!("Value : {guess}");

	// guess = guess + 1;
	// 1. Generating New Value guess + 1 Hence 1000 From RHS
	// 2. let guess Will Redefine Imutable Variable With Initial Value From RHS
	let guess = guess + 1; 
	println!("Value : {guess}");

	// guess = 100;
	// println!("Value : {guess}");

	let x = 5;
	println!("Value : {x}");

	let x = x + 1;
	println!("Value : {x}");

	{
		let x = x * 2;
		println!("Value : {x}");

		{
			let x = 999;
			println!("Value : {x}");

		}
	}
}


//_____________________________________________________________


//	SYSTEM PRINCIPLE
//		PREDICTABLE AND PROVABLE

// 	DESIGN PRINCIPLE
//		 Design Towards IMMutability Rather Than Towards Mutability

// In C/C++/Java/Python
//		Mutability Is Default
// 		int a = 100;
// 		a = 100

//		String greeting = new String(); // greeting is Mutable By Default

// In Rust
//		IMMutability Is Default


// Static Languages
//		C/C++/Java/Rust
//		Most Of The Decisions Are Done At Compile Time
//		Happens At Compile Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable

// Dynamic Languages
//		Python/Ruby/Objective-C/JavaScript
//		Most Of The Decisions Are Done At Run Time
//		Happens At Run Time
//			1. Type Inferrencing : From RHS Value
//			2. Type Binding 	 : Binded To LHS Value/Variable


//_____________________________________________________________

//_____________________________________________________________

// Primitives
// Rust provides access to a wide variety of primitives. A sample includes:

// Every value in Rust is of a certain data type, 
// which tells Rust what kind of data is being specified so 
// it knows how to work with that data. We’ll look at two 

// data type subsets: scalar and compound.

// Scalar Types
// Signed integers: i8, i16, i32, i64, i128 and isize (pointer size)
// Unsigned integers: u8, u16, u32, u64, u128 and usize (pointer size)
// Floating point: f32, f64
// char Unicode scalar values like 'a', 'α' and '∞' (4 bytes each)
// bool either true or false
// The unit type (), whose only possible value is an empty tuple: ()
// Despite the value of a unit type being a tuple, 
//		it is not considered a compound type because 
//		it does not contain multiple values.



// Compound Types
// Arrays like [1, 2, 3]
// Tuples like (1, true)



// Table 3-1: Integer Types in Rust
// Length	Signed	Unsigned 	Memory
// 8-bit	i8		u8 			1
// 16-bit	i16		u16 		2
// 32-bit	i32		u32 		4
// 64-bit	i64		u64			8
// 128-bit	i128	u128		16

// arch		isize	usize



// NOTE :: IMPORTANT
// So how do you know which type of integer to use? 
// If you’re unsure, 

// Rust’s defaults are generally good places to start: 
// 		integer types default to i32.
//		The primary situation in which you’d use isize or usize 
//		is when indexing some sort of collection.


// Table 3-2: Integer Literals in Rust

// Number literals	Example
// Decimal			98_222
// Hex				0xff
// Octal			0o77
// Binary			0b1111_0000
// Byte (u8 only)	b'A'


#[allow(unused)]
fn play_with_types() {
    // In C/C++/Java By Default It's double Type
    // In Rust double is Equivalent to f64
    let x = 98.98; //f64

    // Explicitly Annotating To Make It f32
    let y: f32 = 3.0; // f32

    // addition
    let sum = 5 + 10; // i32

    // subtraction
    let difference = 95.5 - 4.3;

    // multiplication
    let product = 4 * 30;

    // division
    let quotient = 56.7 / 32.2;
    let truncated = -5 / 3; // Results in -1

    // remainder
    let remainder = 43 % 5;

    // Rust char Type Is Unicode Character Type
    // In C/C++ char Is ASCII Character

	let c = 'z';
	// Type Explicitly Annotated
	let z: char = 'Z';
	let zz: char = '😊';

	println!("Value: {c}" );
	println!("Value: {z}" );
	println!("Value: {zz}" );

	// Tuple: Associated Types

	let mut tup1 = (100, 90.90, 1);
	let tup2 = (100, 80.80, 1);

	let (x, y, z) = tup1; // Tuple Unpacking/Decluttering
	println!("Value: {x} {y} {z}");
	tup1 = tup2;

	let (x, y, z) = tup1;	
	println!("Value: {x} {y} {z}");

// In Python
	// let t1 = tup1[0];

	let t1 = tup1.0;
	let t2 = tup1.1;
	let t3 = tup1.2;

	println!("Value: {t1} {t2} {t3}");

	let tup3 = (100, 80.80, 9.9);
	// tup1 = tup3;
	// 	expected `({integer}, {float}, {integer})`, 
	//	found `({integer}, {float}, {float})`

	// let (x, y, z) = tup1;	
	// println!("Value: {x} {y} {z}");

	let tup5: (i64, f64, i64) = (100, 89.89, 1);
	let tup6: (i32, f64, u8) = (100, 89.89, 1);

	let xx: i32 = 90;
	let yy: i64 = 100;

	// let zz = xx + yy; // 	// error[E0308]: mismatched types
	// let zz: i64 = xx + yy;  	// error[E0308]: mismatched types

	// Explicit Type Casting
	let zz: i64 = xx as i64 + yy;
	println!("Value {zz}");

	// error[E0308]: mismatched types
	// 	you can convert an `i64` to an `i32` and 
	//	panic if the converted value doesn't fit
	// let zz: i32 = xx as i64 + yy; 
	// println!("Value {zz}");
}


//_____________________________________________________________

fn play_with_array() {
	// Inferred and Binded Type : [i32 ; 5 ]
	let a = [10, 20, 30, 40, 50 ];

	let _first	= a[0];
	let _second = a[1];

	let mut data = String::new();

	io::stdin()
		.read_line( &mut data )
		.expect("Failed To Read File");

	let index: usize = data
		.trim()
		.parse()
		.expect("Index Is Not A Number");

	let element = a[index];

	println!("Value: {} at Index: {}", element, index );

	// let _some_element = a[8];
	//^^^^ index out of bounds: the length is 5 but the index is 8

	// Type Annotation
	// Explicitly Annotating Type
	let aa: [ i32 ; 5 ] = [ 10, 20, 30, 40, 50 ];
	
	let _aaa = [ 10, 20, 30, 40, 50, 60, 99 ]; // Inferred Type [ i32 ; 7 ]

	println!("Array {:?} ", aa);

	// BEST PRACTICE
	//		Always Prefer for-in Loop Over Indexing Loop
	for element in a { 
		println!("Array a: {}", element);
	}

	// Inferred Type [ &str ; 6 ]
	let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun" ];
	for element in months {
		println!("Array a: {}", element )
	}

 	let mut counter = 0;
 	let _result = loop { // loop Is An Expression
 		counter += 1;
 		if counter == 10 {
 			break counter * 2; // break Followed By Return Expression
 		}
 	};

 	// let _bb = [10, 20, 30, "Ding", "Dong", 99.99]; 
 	// error[E0308]: mismatched types

	// let _bb: [ i32 ; 5 ] = [ 10, 20, 30, 40, 50, 88, 99 ]; // Inferred Type [ i32 ; 7 ]
	// error[E0308]: mismatched types

	// let _cc: [ i32 ; 5 ] = [ 10, 20, 30 ]; // Inferred Type [ i32 ; 3 ]
	// ^^^^^^^^^^^^^^ expected an array with a size of 5, found one with a size of 3
}


//_____________________________________________________________

// The Rust
// compiler guarantees that when you state a value won’t change, 
// it really won’t change, so youdon’t have to keep track of it yourself. 

// Constants
// Like immutable variables, constants are values that are bound to a name and are not allowed
// to change, but there are a few diﬀerences between constants and variables.
// First, you aren’t allowed to use mut with constants. Constants aren’t just immutable by
// default—they’re always immutable. You declare constants using the const keyword instead
// of the let keyword, and the type of the value must be annotated.

// Shadowing
// you can declare a new variable with
// the same name as a previous variable. Rustaceans say that the first variable is shadowed by
// the second, which means that the second variable is what the compiler will see when you
// use the name of the variable. In eﬀect, the second variable overshadows the first, taking any
// uses of the variable name to itself until either it itself is shadowed or the scope ends. 
// We can shadow a variable by using the same variable’s name and repeating the use of the let
// keyword


//_____________________________________________________________

// In Rust
//		By Default Functions In Rust Returns Unit Value of Unit Type
fn function_with_one_arguments( x: i32 ) {
	println!("\nFunction With One Arguemnt Called: {x}")
}

fn function_with_two_arguments( x: i32, y: f64 ) {
	println!("\nFunction With Two Arguemnt Called: {x} {y}")
}

fn some_function() -> i32 {
	let x = 77; // Statement Inferred Type i32
	println!("Some Function Called..."); // Statement
	// In Rust
	//		If You Specify Last Expression 
	//		Than Expression Value Will Be Return Value of Function
	x // Expression and It Will Become Return Value Of Function
}

fn play_with_functions() {
	function_with_one_arguments( 100 );
	function_with_two_arguments( 999, 22.22 );

	let result = some_function();
	println!("Result : {result}" );

	let result_again = function_with_one_arguments( 99 );
	println!("Result Again: {:?}", result_again );
}


//_____________________________________________________________

// Rust is a statically typed language, which means that it must know the
// types of all variables at compile time. The compiler can usually infer 
// what type we want to use based on the value and how we use it.

//_____________________________________________________________

fn play_with_loop() {
	let mut count = 0;

	// Labelled Loop With Label counting_up
	//		Used To Documnent Loop Purpose and/or Jumping
	'counting_up: loop {
		println!("Count : {count}");
		let mut remaining = 10;

		loop { // Nested Loop
			println!("Remaining : {remaining}");
		
			if remaining == 9 {
				break;
			}

			if count == 2 {
				break 'counting_up; 
				// break Followed By Label
				//		After Breaking Loop Jumps To Label
			}
			remaining -= 1;
		} 
		count += 1;
	}
	println!("End Count: {count}");

	let mut number = 3;
	while number != 0 {
		println!("{number}");
		number -= 1
	}
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	// println!("\n\nFunction: helloWorld");
	// helloWorld();

	println!("\n\nFunction: hello_world");
	hello_world();

	println!("\n\nFunction: play_with_mutability");
	play_with_mutability();

	println!("\n\nFunction: play_with_if_else");
	play_with_if_else();

	println!("\n\nFunction: play_with_shadowing");
	play_with_shadowing();

	println!("\n\nFunction: play_with_types");
	play_with_types();

	println!("\n\nFunction: play_with_array");
	play_with_array();

	println!("\n\nFunction: play_with_functions");
	play_with_functions();

	println!("\n\nFunction: play_with_loop");
	play_with_loop();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

