
//_____________________________________________________________

fn play_with_scope() { // Outside Scope
	// Allocated Object At Stack
	let greeting = "Good Evening!";

	println!("Hey: {greeting}");

	// Allocated Object At Heap
	let hello = String::from("Hello Jimmy!!!");
	println!("Hey: {hello}");

	{ // Local/Inside Scope
		let hello = "Hello!";
		println!("Hey: {hello}");
	} // Local hello Dropped

	println!("Hey: {hello}");

	let hello = "Good Afternoon!!!";
	println!("Hey: {hello}");
}

//_____________________________________________________________

// In Rust Every Object Going To Have ONLY ONE OWNER

fn play_with_scope_again() { // Outside Scope
	// Allocated Object At Stack
	// let greeting: String = "Good Evening!";
	// ------   ^^^^^^^^^^^^^^^ expected `String`, found `&str`
	let greeting = "Good Evening!";

	println!("Hey: {greeting}");

	// Object Assignment Doing Copy Semantics
	//		Hence One Duplicate Copy Of The Object Created
	// 		hello And greeting Are Owners Of Different Object
	let hello = greeting; // Copy Semantics
	println!("Hey: {hello}");
	println!("Hey: {greeting}");

	// Allocated Object At Heap
	// greeting1 Is A Reference Which Is Owner Of Object "Hello Jimmy"
	let greeting1: String = String::from("Hello Jimmy!!!");
	 // --------- move occurs because `greeting1` has type `String`, 
	 //			  which does not implement the `Copy` trait
	println!("Hey: {greeting1}");

	// Reference Assignment Doing Move Semantics
	// 		Along with Shifting/Moving Ownership To hello1
	//		hello1 Is Now Onwer Of Object "Hello Jimmy"
	//		greeting1 Is Now No More Owner Of Object "Hello Jimmy"
	let hello1 = greeting1; // Move Semantics
	// 	error[E0382]: borrow of moved value: `greeting1`

	println!("Hey: {hello1}");
	// error[E0382]: borrow of moved value: `greeting1`
	// println!("Hey: {greeting1}");
			// ^^^^^^^^^ value borrowed here after move

	//___________________________________

	let n1 = 99;
	// Object Getting Copied
	let n2 = n1; // Copy Semantics

	println!("Values : {} {}", n1, n2 );

	// Here are some of the types that implement Copy:
	// All the integer types, such as u32.
	// The Boolean type, bool, with values true and false.
	// All the floating point types, such as f64.
	// The character type, char.
	// Tuples, if they only contain types that also implement Copy. 
	// 		For example, (i32, i32) implements Copy, 
	// 		but (i32, String) does not.

	//___________________________________
	// Cloning Example

	let something1 = String::from("BMW Techians");
	println!("Hey: {something1}");
	
	// let something2 = something1 // Move Semantics
	// println!("Hey: {something1}");
	// println!("Hey: {something2}");

	// One More String Object Created In Heap
	//		something3 Will Be Referance As Well As Owner Of This New Object
	let something3 = something1.clone(); // Deep Copy
	println!("Hey: {something1}");
	println!("Hey: {something3}");
}

//_____________________________________________________________

 // ^^^^^^ this parameter takes ownership of the value
 //		Move Semantics :: Ownership Moved To Parameter i.e. some_string
fn play_with_greeting( some_string: String ) {
	println!("Inside :: String Value: {some_string}");
}

fn play_with_number( some_number: i32 ) {
	println!("Inside :: Number Value: {some_number}");
}

fn play_with_function_parameters() {
	let greeting = String::from("Good Afternoon!!!");

	println!("Before Function Call String Value: {greeting}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Move Symantic Is Applied Here
	//		Hence Ownership Shifted To some_string
	//		some_string Is Owner Of The String Object "Good Evening!!!"
	play_with_greeting( greeting ); // Move Semantics
	// println!("After  Function Call String Value: {greeting}");
 	// 				^^^^^^^^ value borrowed here after move

 	let number = 999;
	println!("Before Function Call Number Value: {number}");
	//	Copy Symantic Is Applied Here
	//		Duplicate Copy Of Object Created 
	//		And Assigned To Parameter some_number
	play_with_number( number ); // Copy Semantics
	println!("After  Function Call String Value: {number}");
}


//_____________________________________________________________

 // ^^^^^^ this parameter takes ownership of the value
 //		Move Semantics :: Ownership Moved To Parameter i.e. some_string
fn play_with_greeting_again( some_string: String ) -> String {
	println!("Inside :: String Value: {some_string}");

	// Last Expression Is Return Value Function
	//	Move Semantics
	//		some_string Ownership Is Shifted Back To The Caller
	some_string // Expression
}

fn say_greeting() -> String {
	// Object Allocated At Heap
	let greeting = String::from("Good Afternoon!!!");

	// Last Expression Is Return Value Function
	//	Move Semantics
	//		greeting Ownership Is Shifted To The Caller
	greeting // Expression
}


fn play_with_function_parameters_again() {
	let greeting = String::from("Good Afternoon!!!");

	println!("Before Function Call String Value: {greeting}");
	// greeting Is Getting Assigned To Parameter some_string
	//		Move Symantic Is Applied Here
	//		Hence Ownership Shifted To some_string
	//		some_string Is Owner Of The String Object "Good Evening!!!"
	// play_with_greeting_again( greeting ); // Move Semantics
	// let greeting_back = play_with_greeting_again( greeting ); // Move Semantics
	// println!("After  Function Call String Value: {greeting_back}");
 	// 				^^^^^^^^ value borrowed here after move

 	// Use The Already Existing Domain Name
 	//		Use Case Of Shadowing
	let greeting = play_with_greeting_again( greeting ); // Move Semantics
	println!("After  Function Call String Value: {greeting}");

	say_greeting();

	// Shifted The Returned Object Ownership To greet
	let greet = say_greeting();
	println!("After  Function Call String Value: {greet}");
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_scope");
	play_with_scope();

	println!("\n\nFunction: play_with_scope_again");
	play_with_scope_again();

	println!("\n\nFunction: play_with_function_parameters");
	play_with_function_parameters();

	println!("\n\nFunction: play_with_function_parameters_again");
	play_with_function_parameters_again();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

