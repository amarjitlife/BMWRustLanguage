
___________________________________________________________________________________

DAY 01
___________________________________________________________________________________

	A1: ENVIRONMENT SETUP
		Please Setup Rust Programming Compilers

	A2: REVISION ASSIGNMENT:
		Practice And Experiment With Code Examples Done Till Now In Class

	A3: READING ASSIGNMENT IN C:
		Chapter 02: Types, Operators and Expressions
			The C Programming Language, 2nd Edition, By Kernighm and Ritchie

	A4: READING ASSIGNMENT IN RUST:
		RUST READING MATERIAL:
			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

		Reading Assignment:
			Rust Concepts
				Variables and Mutability
				Data Types
				Functions
				Control Flows
				https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
				https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html

			Rust Naming Convention
				https://rust-lang.github.io/api-guidelines/naming.html

	A5: READING ASSIGNMENT FOR CURIOUS LEANERS:
			Dead Code Security Flaw
				https://www.sei.cmu.edu/library/unused-code-a-hidden-time-bomb/

___________________________________________________________________________________

DAY 02
___________________________________________________________________________________

	A1: REVISION ASSIGNMENT:
		Practice And Experiment With Code Examples Done Till Now In Class

	A2: READING AND PRACTICE CODE ASSIGNMENT:
			Chapter 02: Types, Operators and Expressions
				The C Programming Language, 2nd Edition, By Kernighm and Ritchie

		RUST READING MATERIAL:
			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

		Reading Assignment:
			1. Rust Concepts
				Variables and Mutability
				Data Types
				Functions
				Control Flows
				https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
				https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html

			2. Rust Ownership
				https://doc.rust-lang.org/book/ch04-00-understanding-ownership.html
			
			3. Rust Naming Convention
				https://rust-lang.github.io/api-guidelines/naming.html

	A3: READING ASSIGNMENT FOR CURIOUS LEANERS:
			Dead Code Security Flaw
				https://www.sei.cmu.edu/library/unused-code-a-hidden-time-bomb/

___________________________________________________________________________________

DAY 03
___________________________________________________________________________________

___________________________________________________________________________________

DAY 04
___________________________________________________________________________________

___________________________________________________________________________________

DAY 05
___________________________________________________________________________________

___________________________________________________________________________________

DAY 06
___________________________________________________________________________________

___________________________________________________________________________________

DAY 07
___________________________________________________________________________________


