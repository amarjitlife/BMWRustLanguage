___________________________________________________________________________________
___________________________________________________________________________________

Write Following sum Function In C
	Function Should Return Valid Arithematic Integer Sum
	Or Print Can't Calculate Valid Sum For Given a And b Values

	int sum( int a, int b )


Design 01
	int sun( int a, int b ) {
		return a + b;
	}

Design 02
	signed long sun( int a, int b ) {
		return a + b;
	}


Design 03

//_______________________________________________

// Function Can Return Only 1 Value
//		Either Return Valid Result Or Error Code

int sum(int a, int b, int *error) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        *error = 1; // overflow or underflow
    }
    
    int result = a + b;
    *error = 0;
    return result; 
}

int sum(int a, int b, int *result) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        return 0; // overflow or underflow
    }
    
    *result = a + b;
    return 1; // success
}


//_____________________________________________________________


// Abdul Nazar P
// why this code working

fn play_with_string_mutability() {
    let x = String::from("Sample String");
    let mut x1 = x;
   
    let x2 = &mut x1; 
    let x3: &mut String = x2;
    x2.push_str(" - Modified");

    println!("x2 - {}", x2);
    println!("x2 - {}", x3);

    // error[E0499]: cannot borrow `*x2` as mutable more than once at a time
    // error[E0502]: cannot borrow `x2` as immutable because it is also borrowed as mutable
}


___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________
___________________________________________________________________________________


