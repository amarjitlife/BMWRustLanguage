
//_____________________________________________________________
//
// SLICES IN RUST
//_____________________________________________________________

fn play_with_slices() {
	let s: String = String::from("Good Morning!!!");
	let length = s.len();

	println!("String Length: {length}"); 	// String Length: 15
	println!("String Value: {s}"); 			// String Value: Good Morning!!!

	println!("\n");

	// let hello = s[0..5];
	// error[E0277]: the size for values of type `str` cannot be known at compilation time
//    |         ^^^^^ doesn't have a size known at compile-time
//    |
//    = help: the trait `Sized` is not implemented for `str`
//    = note: all local variables must have a statically known size
// 		help: consider borrowing here

	let hello = &s[0..5]; // hello = ["Good "] // 5 - 0 = 5 Length
	let world = &s[6..11]; // 11 - 6 = 5 Length

	println!("Slice Value: {hello}");
	println!("Slice Length: {}", hello.len() );

	println!("Slice Value: {world}");
	println!("Slice Length: {}", world.len() );

	// let hello1: String = &s[0..5]; // hello = ["Good "] // 5 - 0 = 5 Length
	// let world1: String = &s[6..11]; // 11 - 6 = 5 Length
  // |                 ------   ^^^^^^^^ expected `String`, found `&str`
  // |                 expected due to this


	let hello1: &str = &s[0..5]; // hello = ["Good "] // 5 - 0 = 5 Length
	let world1: &str = &s[6..11]; // 11 - 6 = 5 Length

	println!("Slice Value: {hello1}");
	println!("Slice Length: {}", hello1.len() );

	println!("Slice Value: {world1}");
	println!("Slice Length: {}", world1.len() );

	println!("\n");

	let slice = &s[0..2];
	println!("Slice Value: {slice}");
	println!("Slice Length: {}", slice.len() );

	let slice = &s[..2]; // StartIndex Default To 0
	println!("Slice Value: {slice}");
	println!("Slice Length: {}", slice.len() );

	let slice = &s[3..length];
	println!("Slice Value: {slice}");
	println!("Slice Length: {}", slice.len() );

	let slice = &s[3..]; // EndIndex Default To Length
	println!("Slice Value: {slice}");
	println!("Slice Length: {}", slice.len() );

	println!("\n");
	// In Rust Strings Are Unicode String
	//		Unicode String Starts and Ends With ""
	//		Unicode String Consists of Unicode Characters

	let ss = "Hello World!😊♥"; // Expected 14 Characters Length
	let length = ss.len(); 		// Buffers Length In Number Of Bytes
	// String Value: Hello World!😊♥
	// String Length: 19 				// 12 + 4 + 3

    // The type of ss here is &str : it’s a slice pointing to that 
    // specific point of the binary. This is also why string literals 
    // are immutable; &str is an immutable reference.
	// String Literals Means String Value In "" e.g. "Good Morning!!!"

	println!("String Value: {ss}");
	println!("String Length: {length}");

	let ch: char = '😊';
	println!("Character Value: {ch}");

// In Rust
	// The char type represents a single character. 
	//		More specifically, since ‘character’ isn’t a well-defined 
	//		concept in Unicode, char is a ‘Unicode scalar value’.

	// Unicode scalar values are also the exact set of values that may be encoded in UTF-8. 
	//		Because char values are Unicode scalar values and functions may 
	//		assume incoming str values are valid UTF-8, it is safe to store 
	//		any char in a str or read any character from a str as a char

// In Java
//		char Is 2 Byte Unicode Character with UTF-16 Encoding

	println!("\n");

	// TausifSuleman Sarigat
	let t = String::from("Hello"); // StartIndex = 0 and EndIndex = 5

	println!("String Value: {t}"); 			
	println!("String Length: {}", t.len()); 	

	// And then take slice 0..5?
	// let slice = t[0..5]; // Index Range 0..5 Means Index From [0, 5)
	 // ^^^^^ doesn't have a size known at compile-time

	let slice = &t[0..5]; // Index Range 0..5 Means Index From [0, 5)
	println!("Slice Value: {slice}");
	println!("Slice Length: {}", slice.len() );

	// let slice = &t[0..6]; // Index Range 0..6 Means Index From [0, 6)
	// println!("Slice Value: {slice}");
	// println!("Slice Length: {}", slice.len() );
	// thread 'main' (21245) panicked at RustSlices.rs:116:19:
	// end byte index 6 is out of bounds for string of length 5
	// note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace
}

//_____________________________________________________________


//_____________________________________________________________
//
// +++++  EXPERIMENT BELOW CODE AND RAISE YOUR HANDS MOMENT DONE!!!
//_____________________________________________________________


fn first_word( s: &String ) -> &str {
	let bytes = s.as_bytes();
	// Enumerate Will Generate Sequence Of Tuples
	//		Tuple Having Two Members ( index, value )
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}

	&s[..]
}

// This Is More General API
fn first_word_better( s: &str ) -> &str {
	let bytes = s.as_bytes();
	// Enumerate Will Generate Sequence Of Tuples
	//		Tuple Having Two Members ( index, value )
	for( i, &item ) in bytes.iter().enumerate() {
		if item == b' ' {
			return &s[0..i];
		}
	}

	&s[..]
}

// If we have a string slice, we can pass that directly. 
// 		If we have a String, we can pass a slice of the String or 
//		a reference to the String. 
//		This flexibility takes advantage of deref coercions, 
//		a feature we will cover in the 
//		“Using Deref Coercions in Functions and Methods” section of Chapter 15.


fn play_with_first_word() {
	let sentence = String::from("How Are You Doing?");

	println!("Sentence :: {sentence}");
	// &String Only Can Be Passed
	let word = first_word( &sentence ); 	// Borrow Semantic
	println!("Sentence :: {word}");

	println!("Sentence :: {sentence}");
	// &str And &String Can Be Passed
	let word = first_word_better( &sentence[..] ); // Borrow Semantic
	println!("Sentence :: {word}");

	println!("Sentence :: {sentence}");
	// &str
	let word = first_word_better( &sentence[..6] ); // Borrow Semantic
	println!("Sentence :: {word}");

	println!("Sentence :: {sentence}");
	// &str
	let word = first_word_better( &sentence[4..7] ); // Borrow Semantic
	println!("Sentence :: {word}");

	println!("Sentence :: {sentence}");
	// &String
	let word = first_word_better( &sentence ); // Borrow Semantic
	println!("Sentence :: {word}");
}

/*
// In C++/Java/Kotlin/TypeScript/JavaScript

Suppose You Are Creating Three Classes/Type Using Inheritance
<--- Points From Child Class/Type To Parent Class/Type
Person <--- Employee <--- Manager

// What Is The Type Of m???
Manager m = new Manager();

Employee e = m;
Person p1 = m;
Person p2 = new Employee();
*/


//_____________________________________________________________

fn printing_byte_buffer( s: &str ) {
	let bytes = s.as_bytes();
	for byte in bytes {
		// print!(" {byte} ");
		print!(" {:02x}", byte)
	}
}

fn play_with_printing_byte_buffer() {
	let sentence = String::from("How Are You Doing?😊♥");
	printing_byte_buffer( &sentence );
}


// Function: play_with_printing_byte_buffer
//  48 6f 77 20 41 72 65 20 59 6f 75 20 44 6f 69 6e 67 3f f0 9f 98 8a e2 99

// Verify These Numbers Are Related To Unicode Points?
//		What Encoding It Uses?
//		How ASCII Is Interprerated?

//_____________________________________________________________

fn play_with_types() {
	
	let s1 : String = String::from("Hello!!!");
	println!("String Value: {s1}");

	// let s2 : String = "Hello World";
	// ^^^^^^^^^^^^^ expected `String`, found `&str`

	let s2 : &str = "Hello World";
	println!("String Value: {s2}");

	// let s3: &str = s1;
	// ----   ^^ expected `&str`, found `String`

	let s3: &str = &s1;
	println!("String Value: {s3}");

	// let s4: String = s2;
	// |             ------   ^^ expected `String`, found `&str`

	let s4: String = s2.to_string();
	println!("String Value: {s4}");

}


//_____________________________________________________________

// Abdul Nazar P
// why this code working

fn play_with_string_mutability() {
	let x = String::from("Sample String");
    let mut x1 = x;
   
    let x2 = &mut x1; 
    let x3: &mut String = x2;
    x2.push_str(" - Modified");

    println!("x2 - {}", x2);
    println!("x2 - {}", x3);

	// error[E0499]: cannot borrow `*x2` as mutable more than once at a time
	// error[E0502]: cannot borrow `x2` as immutable because it is also borrowed as mutable
}


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_slices");
	play_with_slices();

	println!("\n\nFunction: play_with_first_word");
	play_with_first_word();

	println!("\n\nFunction: play_with_printing_byte_buffer");
	play_with_printing_byte_buffer();

	println!("\n\nFunction: play_with_types");
	play_with_types();

	println!("\n\nFunction: play_with_string_mutability");
	play_with_string_mutability();

	// println!("\n\nFunction: ");	
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

