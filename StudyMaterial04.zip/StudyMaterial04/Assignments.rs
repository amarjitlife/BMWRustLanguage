
___________________________________________________________________________________

DAY 01
___________________________________________________________________________________

	A1: ENVIRONMENT SETUP
		Please Setup Rust Programming Compilers

	A2: REVISION ASSIGNMENT:
		Practice And Experiment With Code Examples Done Till Now In Class

	A3: READING ASSIGNMENT IN C:
		Chapter 02: Types, Operators and Expressions
			The C Programming Language, 2nd Edition, By Kernighm and Ritchie

	A4: READING ASSIGNMENT IN RUST:
		RUST READING MATERIAL:
			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

		Reading Assignment:
			1. Rust Concepts
				Variables and Mutability
				Data Types
				Functions
				Control Flows
				https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
				https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html

			2. Rust Naming Convention
				https://rust-lang.github.io/api-guidelines/naming.html

	A5: READING ASSIGNMENT FOR CURIOUS LEANERS:
			Dead Code Security Flaw
				https://www.sei.cmu.edu/library/unused-code-a-hidden-time-bomb/

___________________________________________________________________________________

DAY 02
___________________________________________________________________________________

	A1: REVISE, PRACTICE AND EXPERIMENT ASSIGNMENT
		Revise, Practice And Experiment With Code Examples Done Till Now In Class

	A2: READING AND PRACTICE CODE ASSIGNMENT

		READINGS IN C ASSIGNMENTS
			Chapter 02: Types, Operators and Expressions
			The C Programming Language, 2nd Edition, By Kernighm and Ritchie

		READINGS IN RUST ASSIGNMENTS
			1. Rust Concepts
				Variables and Mutability
				Data Types
				Functions
				Control Flows
				https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
				https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html

			2. Rust Ownership
				https://doc.rust-lang.org/book/ch04-00-understanding-ownership.html
			
			3. Rust Naming Convention
				https://rust-lang.github.io/api-guidelines/naming.html

			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

	A3: READING ASSIGNMENT [ FOR CURIOUS LEANERS ]
			Dead Code Security Flaw
				https://www.sei.cmu.edu/library/unused-code-a-hidden-time-bomb/

___________________________________________________________________________________

DAY 03
___________________________________________________________________________________

	A1: REVISE, PRACTICE AND EXPERIMENT ASSIGNMENT
		Revise, Practice And Experiment With Code Examples Done Till Now In Class

	A2: READING AND PRACTICE CODE ASSIGNMENT

		READINGS IN C ASSIGNMENTS
			Chapter 05: Pointers And Arrays
			The C Programming Language, 2nd Edition, By Kernighm and Ritchie

		READINGS IN RUST ASSIGNMENTS
			1. Rust Concepts
				Variables and Mutability
				Data Types
				Functions
				Control Flows
				https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
				https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html

			2. Rust Ownership
				https://doc.rust-lang.org/book/ch04-00-understanding-ownership.html
			
			3. Rust Naming Convention
				https://rust-lang.github.io/api-guidelines/naming.html

			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

	A3: READING ASSIGNMENT [ FOR CURIOUS LEANERS ]
			Dead Code Security Flaw
				https://www.sei.cmu.edu/library/unused-code-a-hidden-time-bomb/

___________________________________________________________________________________

DAY 04
___________________________________________________________________________________


	A1: REVISE, PRACTICE AND EXPERIMENT ASSIGNMENT
		Revise, Practice And Experiment With Code Examples Done Till Now In Class

	A2: READING AND PRACTICE CODE ASSIGNMENT

		READINGS IN C AND PRACTICE ASSIGNMENTS
			Chapter 05: Pointers And Arrays
			The C Programming Language, 2nd Edition, By Kernighm and Ritchie

		READINGS IN RUST AND PRACTICE ASSIGNMENTS
			https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html
			https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html
			https://doc.rust-lang.org/book/ch04-03-slices.html

			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

	A3: READING ASSIGNMENT [ FOR CURIOUS LEANERS ]
		https://users.rust-lang.org/t/why-is-the-size-of-an-array-slice-not-known-at-compilation-time/124231/9
		https://ktkaufman03.github.io/blog/2023/04/20/rust-compile-time-checks/

___________________________________________________________________________________

DAY 05
___________________________________________________________________________________


___________________________________________________________________________________

DAY 06
___________________________________________________________________________________


___________________________________________________________________________________

DAY 07
___________________________________________________________________________________


