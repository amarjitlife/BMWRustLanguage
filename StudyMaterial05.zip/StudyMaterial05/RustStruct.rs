#![allow(unused)]

//_____________________________________________________________

// In Rust

// Associative Types
// 	Tuple
// 	Structure


// A struct, or structure, is a custom data type that lets you 
// 	package together and name multiple related values that 
//	make up a meaningful group

// Structure Members Are Called fields, attribute

// Structure and Tuple in that both hold multiple related values. 
// Like tuples, the pieces of a struct can be different types. 
// Unlike with tuples, in a struct you’ll name each piece of data 
// so it’s clear what the values mean.

//_____________________________________________________________

struct User {
	active: bool, // Attribute Or Field
	username: String,
	email: String,
	sign_in_count: u64, 
}

fn play_with_user() {
	let user = User {
		active: true,
		username: String::from("Gabbar Singh"),
		email: String::from("gabbar@ramgarh.com"),
		sign_in_count: 1,
	};

	println!(" user: {} {} {} {}", user.active, user.username, user.email, user.sign_in_count);

	let mut user1 = User {
		active: true,
		username: String::from("Gabbar Singh"),
		email: String::from("gabbar@ramgarh.com"),
		sign_in_count: 1,
	};

	println!(" user: {} {} {} {}", user1.active, user1.username, user1.email, user1.sign_in_count);
	user1.email = "gabbar@gmail.com".to_string();
	user1.active = false;
	user1.sign_in_count = 10;
	user1.username = String::from("Gabbar Singh Decoit!");
	println!(" user: {} {} {} {}", user1.active, user1.username, user1.email, user1.sign_in_count);

	let user2 = User {
		active: true,
		username: "Gabbar Singh".to_string(),
		email: String::from("gabbar@ramgarh.com"),
		sign_in_count: 1,
	};

	println!(" user: {} {} {} {}", user2.active, user2.username, user2.email, user2.sign_in_count);
	
	let user3 = User { // Member Order Can Be Changed
		username: "Gabbar Singh".to_string(),
		active: user1.active,
		email: user1.email,
		sign_in_count: user1.sign_in_count,
	};

	println!(" user: {} {} {} {}", user3.active, user3.username, user3.email, user3.sign_in_count);

	let user4 = User { // Member Order Can Be Changed
		username: "Gabbar Singh".to_string(),
		..user2 // Assings user2 Member Values To user5 For Remaining Fields/Attributes/Members
	};

	println!(" user: {} {} {} {}", user4.active, user4.username, user4.email, user4.sign_in_count);
	
	//_________________________________________________

	let user11 = User {
		active: true,
		username: String::from("Gabbar Singh"),
		email: String::from("gabbar@ramgarh.com"),
		sign_in_count: 1,
	};

	println!(" user: {} {} {} {}", user11.active, user11.username, user11.email, user11.sign_in_count);

	let user22 = user11; // Move Semantics
	println!(" user: {} {} {} {}", user22.active, user22.username, user22.email, user22.sign_in_count);
	// println!(" user: {} {} {} {}", user11.active, user11.username, user11.email, user11.sign_in_count);


}

//_____________________________________________________________

// Factory Function:
//		Function Having Role To Create Objects
fn build_user( email: String, username: String ) -> User {
	// Expression and Return Value Of Function
	User { // Creating New User 
		username: username,
		email: email,
		active: true,
		sign_in_count: 1,
	}
}

fn build_user_again( email: String, username: String ) -> User {
	// Expression and Return Value Of Function
	User { // Creating New User
		// Shortcut Syntax Of Intialisation
		//		User Whenever Function Parameter Names Are Same
		//		As Structure Field Names 
		username,
		email,
		active: true,
		sign_in_count: 1,
	}
}

fn play_with_build_user() {
	let gabbar = build_user( 
		String::from("gabbar@gmail.com"),
		String::from("Gabbar Singh")
	);

	println!(" Gabbar: {} {} {} {}", gabbar.active, gabbar.username, gabbar.email, gabbar.sign_in_count);

	let sambha = build_user_again( 
		String::from("sambha@gmail.com"),
		String::from("Sambha")
	);

	println!(" Sambha: {} {} {} {}", sambha.active, sambha.username, sambha.email, sambha.sign_in_count);

	let email = 	String::from("someone@gmail.com");
	let username =	String::from("Someone Singh");

	println!("Data : {} {}", email, username);

	let someone = build_user(email, username); // Move Semantics
   // |                              ----- value moved here

	println!(" Someone: {} {} {} {}", someone.active, someone.username, someone.email, someone.sign_in_count);
	// println!("Data : {} {}", email, username);

}

//_____________________________________________________________

struct Rectangle1 {
	width : u32,
	height: u32,
}

// Design Choice 01
fn area( width: u32, height: u32 ) -> u32 {
	width * height // Expression
}

// Design Choice 02
fn area_better( dimension: (u32, u32)  ) -> u32 {
	dimension.0 * dimension.1 // Expression
}

// Design Choice 03
fn area_best( rectangle: Rectangle1  ) -> u32 {
	rectangle.width * rectangle.height // Expression
}

// error[E0428]: the name `area` is defined multiple times
//		Rust Doesn't Support Function Overloading Based On Function Name

fn play_with_area() {
	let width1 = 30;
	let height1 = 50;

	let result = area( width1, height1 );
	println!("Area : {result}");

	let rectangle_dimension = ( width1, height1 );
	let result = area_better( rectangle_dimension );
	println!("Area : {result}");

	let rectangle = Rectangle1 {
		width : 30,
		height: 50,
	};

	let result = area_best( rectangle );
	println!("Area : {result}");
}


//_____________________________________________________________

// Using Tuple Structs without Named Fields to Create Different Types

// Rust also supports structs that look similar to tuples, called tuple structs. 
// Tuple structs have the added meaning the struct name provides 
// but don’t have names associated with their fields; rather, 
// they just have the types of the fields

// TUPLE STRUCTS
// Custom Tuple Type Using Structure
//		Named Tuple Type

#[derive(Debug)]
struct Color(u8, u8, u8);

#[derive(Debug)]
struct Point2D( i32, i32 );

#[derive(Debug)]
struct Point3D( i32, i32, i32 );

#[allow(dead_code)]
#[derive(Debug)]
struct ColorAgain {
	red: u8,
	green: u8,
	blue: u8,
}

#[allow(dead_code)]
#[derive(Debug)]
struct Point3DAgain { 
	x: i32, 
	y: i32, 
	z: i32,
}

fn play_with_custom_tuple_types() {
	let white: (u8, u8, u8) = (255, 255, 255);

	println!("White: {:?}", white);

	let black = Color( 0, 0, 0 );
	let origin2 = Point2D( 0, 0 );
	let origin3 = Point3D( 0, 0, 0 );

	println!(" {:?}", black );
	println!(" {:?}", origin2 );
	println!(" {:?}", origin3 );
}


//_____________________________________________________________

// Unit-Like Structs Without Any Fields
//	You can also define structs that don’t have any fields! 
//	These are called unit-like structs because they behave similarly to ()
//	
// Unit-like structs can be useful when you need to implement a trait 
// on some type but don’t have any data that you want to store in the type itself

// Used To Create A Type
#[derive(Debug)] // It Derives Diplay Traits for Debugging 
struct AlwaysEqual;

fn play_with_struct_without_fields() {
	let subject: AlwaysEqual = AlwaysEqual ;

	// println!("AlwaysEqual Value: {}", subject );
	// 		error[E0277]: `AlwaysEqual` doesn't implement `std::fmt::Display`

	println!("AlwaysEqual Value: {:?}", subject );

}

//_____________________________________________________________
//
// METHODS - MEMBER FUNCTIONS
//_____________________________________________________________


#[derive(Debug)] // It Derives Diplay Traits for Debugging 
struct Rectangle {
	width: u32,
	height: u32,
}

// Implementation Block
impl Rectangle {
	// Method Or Member Function
	//		Method Or Member Function If First Argument Is self
	//		Member Functions Always Takes First Argument self Of Self Type
	//		Methods Access Using Objet Followed By . Operator

	//		area() Is A Member Function Of Type Rectangle
	//		&Self means We Are Borrowing self

	fn area( self : &Self ) -> u32 {
		self.width * self.height
	}

	// &self Is Shortcut of self: &Self
	// &self Is Equivalent To Passing self: &Self
	fn is_width( &self ) -> bool {
		self.width > 0
	}

	fn is_height( self : &Self ) -> bool {
		self.height > 0
	}

	// Method Taking More Than 1 Arguments
	fn can_hold_inside( &self, other: &Rectangle ) -> bool {
		self.width > other.width && self.height > other.height
	}

	// Associative Function
	// 		Associated functions that aren’t methods are often used for 
	//		constructors that will return a new instance of the struct. 
	//		These are often called new , but new isn’t a special name and 
	//		isn’t built into the language

	//		Because It Doesn't Take self As First Argument

	// Factory Function i.e. Function Which Creates Objects
	//		Here square Function Is Createing Object Of Self Type
	//		Called Using Type Name Followed By ::

	// Factory Function - Creating Object Of Self Type
	fn square( size: u32 ) -> Self {
		Self { 
			width: size,
			height: size,
		} // Expression and Return Value Of Function
	}
}


fn play_with_methods_associative_functions() {	
	let rectangle1 = Rectangle {
		width : 30,
		height : 50,
	};

	let rectangle2 = Rectangle {
		width : 40,
		height : 40,
	};

	let rectangle3 = Rectangle {
		width : 10,
		height : 20,
	};

	// Calling Rectangle Object Methods
	println!(" {:?} ", rectangle1 ); 
	println!(" {:?} ", rectangle2 ); 
	println!(" {:?} ", rectangle3 ); 

	println!("Rectangle Area: {}", rectangle1.area() ); 
	println!("Rectangle Width: {}", rectangle1.is_width() );
	println!("Rectangle Hold: {}", rectangle1.can_hold_inside( &rectangle2 ) );
	println!("Rectangle Hold: {}", rectangle1.can_hold_inside( &rectangle3 ) );

	// Calling Associative Function
	let square = Rectangle::square( 50 ); 
	println!("Square: {:?}", square ); 
	println!("Square Area: {}", square.area() ); 

}


//_____________________________________________________________
//_____________________________________________________________

// Methods are similar to functions: we declare them with the fn keyword and a name, they
// can have parameters and a return value, and they contain some code that’s run when the
// method is called from somewhere else. Unlike functions, methods are defined within the
// context of a struct (or an enum or a trait object

// and their first parameter is always self , which represents the instance of the
// struct the method is being called on.

// instead of rectangle: &Rectangle . The &self is actually short for self: &Self . 

// Within an impl block, the type Self is an alias for the type
// that the impl block is for. Methods must have a parameter named 
// self of type Self for their first parameter, so Rust lets you 
// abbreviate this with only the name self in the first parameter spot. 

// Note that we still need to use the & in front of the self shorthand to
// indicate this method borrows the Self instance, 

// Just as we did in rectangle: &Rectangle . Methods can take ownership of self, 
// borrow self immutably as we’ve done here, or borrow self mutably, 
// just as they can any other parameter.

// We’ve chosen &self here for the same reason we used &Rectangle in the function version:
// we don’t want to take ownership, and we just want to read the data in the struct, 
// not write to it. If we wanted to change the instance that we’ve called the method 
// on as part of what the method does, we’d use &mut self as the first parameter.

// Note that we can choose to give a method the same name as one of the struct’s fields.
// 		when we follow rect1.width with parentheses, 
//				Rust knows we mean the method width . 
//		When we don’t use parentheses, 
//				Rust knows we mean the field width .

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_user");
	play_with_user();

	println!("\n\nFunction: play_with_build_user");
	play_with_build_user();

	println!("\n\nFunction: play_with_area");
	play_with_area();

	println!("\n\nFunction: play_with_custom_tuple_types");
	play_with_custom_tuple_types();

	println!("\n\nFunction: play_with_struct_without_fields");
	play_with_struct_without_fields();

	println!("\n\nFunction: play_with_methods_associative_functions");
	play_with_methods_associative_functions();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

