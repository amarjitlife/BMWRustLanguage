#![allow(unused)]

//_____________________________________________________________

#[derive(Debug)]
enum IpAddrKind {
	V4,
	V6,
}

fn route( ip_kind : IpAddrKind ) {
	// Dummy Function... Code Goes H6ere...
}

fn play_with_ipaddress_enum1() {
	let four = IpAddrKind::V4;
	let six = IpAddrKind::V6;

	println!("{:?}", four);
	println!("{:?}", six);

	route( IpAddrKind::V4 );
	route( six );

	// println!("{:?}", four);
	// println!("{:?}", six);

}

//_____________________________________________________________

fn play_with_ipaddress_enum_and_structure() {
	// Domain of IP Address Is Simulated Using Combination of Enum and Structure
	#[derive(Debug)]
	enum IpAddrKind {
		V4,
		V6,
	}

	#[derive(Debug)]
	struct IpAddr {
		kind: IpAddrKind,
		address: String,
	}

	let home = IpAddr {
		kind: IpAddrKind::V4,
		address: String::from("127.0.0.1"),
	};

	let loopback = IpAddr {
		kind: IpAddrKind::V6,
		address: String::from("::1"),
	};

	println!("{:?}", home);
	println!("{:?}", loopback);
}


//_____________________________________________________________

fn play_with_ipaddress_enum2() {
	// Domain of IP Address Is Simulated Using Only Enum
	#[derive(Debug)]
	#[derive(PartialEq)]
	enum IpAddr {
		V4(String),
		V6(String),
	}

	// #[derive(Debug)]
	// struct IpAddr {
	// 	kind: IpAddrKind,
	// 	address: String,
	// }

	// let home = IpAddr {
	// 	kind: IpAddrKind::V4,
	// 	address: String::from("127.0.0.1"),
	// };

	// let loopback = IpAddr {
	// 	kind: IpAddrKind::V6,
	// 	address: String::from("::1"),
	// };

	let home 	 = IpAddr::V4( String::from("127.0.0.1") );
	let home1 	 = IpAddr::V4( String::from("127.0.0.1") );
	let server 	 = IpAddr::V4( String::from("299.99.99.10") );

	let loopback = IpAddr::V4( String::from("::1") );

	println!("{:?}", home);
	println!("{:?}", loopback);

	// Comparing Enum Values
	let result = home == home1;
	println!("Result : {:?}", result );

	let result = home == server;
	println!("Result : {:?}", result );
}

//_____________________________________________________________

fn play_with_ipaddress_enum3() {
	// Domain of IP Address Is Simulated Using Only Enum

	#[derive(Debug)]
	#[derive(PartialEq)]
	struct IpV4Addr {
		part1: u8,
		part2: u8,
		part3: u8,
		part4: u8,
	}

	#[derive(Debug)]
	#[derive(PartialEq)]
	struct IpV6Addr {
		part1: u64,
		part2: u64,
		part3: u64,
		part4: u64,
		part5: u64,
		part6: u64,
	}

	// #[derive(Debug)]
	// #[derive(PartialEq)]
	// struct IpV4Addr( u8, u8, u8, u8 )

	// #[derive(Debug)]
	// #[derive(PartialEq)]
	// struct IpV6Addr( u64, u64, u64, u64, u64, u64 )

	#[derive(Debug)]
	#[derive(PartialEq)]
	enum IpAddr {
		V4(IpV4Addr),
		V6(IpV6Addr),
	}

	// Change Following Code To Use Above Defintions
	// let home 	 = IpAddr::V4( String::from("127.0.0.1") );
	// let home1 	 = IpAddr::V4( String::from("127.0.0.1") );
	// let server 	 = IpAddr::V4( String::from("299.99.99.10") );

	// let loopback = IpAddr::V4( String::from("::1") );

	// println!("{:?}", home);
	// println!("{:?}", loopback);
}

//_____________________________________________________________

// In Rust
//		Definition Of Option Type As Follows:

// pub enum Option<T> {
// 		// Representing Invalid Value 
// 		None,
// 		// Valid Value Wrapped Inside Some 
// 		//		i.e. Treat Some As Bucket Having Valid Value
// 		Some(T),    
// }

// Design Choice 03
fn summation( a: i32, b: i32 ) -> Option<i32> {
	let min_val = i32::MIN;
	let max_val = i32::MAX;

	let mut result: Option<i32> = None;

	if (( b > 0 && a > max_val -b ) ||
		 ( b < 0 && a < min_val - b )) { // Error : Overflow/Underflow
		result = None;  // Invalid Value
	} else {
		result = Some( a + b ) // Valid Value
	}

	result // Expression It's Return Value Of Function
}


fn play_with_summation_optional() {
	let a = 888888;
	let b = 111;

	let result = summation( a, b );
	println!("Result : {:?}", result);

	// Pattern Mathcing Using match Construct
	match result {
		Some(value) 	=> println!("Calculated Sum : {:?}", value),
		None 			=> println!("Error : Summation Is Invalid For Given Values: {} {}", a, b),
	}

	let a = 2147483647;
	let b = 111;

	// What Is The Type Of result?
	//		Option<i32>
	let result = summation( a, b );
	println!("Result : {:?}", result);

	// Pattern Mathcing Using match Expression
	//		match Expression Have Return Value
	//			Return Value Depends On Which Arm Matched
	//			Match Arm Mapped Block Value Will Become Return Value Of match Expression
	//				Mapped Block Is Followed By =>  

	let something = match result {
		Some(value) 	=> { 
			println!("Calculated Sum : {:?}", value);
			1 // Using To Show match Returns Value
		}
		None 			=> {
			println!("Error : Summation Is Invalid For Given Values: {} {}", a, b);
			0 // Using To Show match Returns Value
		}
	};

	println!("Something : {:?}", something);
}


//_____________________________________________________________

fn play_with_returing_optional() {

    fn plus_one(x: Option<i32>) -> Option<i32> {
        match x {
            None 	=> None,
            Some(i) => Some(i + 1),
        }
    }

    let five 	= Some(5);
    let six 	= plus_one(five);
    let none 	= plus_one(None);

    // fn plus_one_again(x: Option<i32>) -> Option<i32> {
    //     match x {
        	 // ^ pattern `None` not covered
    //         Some(i) => Some(i + 1),
    //     }
    // }

    // let five1 = Some(5);
    // let six1 = plus_one_again(five);
    // let none1 = plus_one_again(None);
}

//______________________________________________________________


fn play_with_match_default() {
    let dice_roll = 9;

    match dice_roll {
        3 		=> add_fancy_hat(),
        7 		=> remove_fancy_hat(),
        other 	=> move_player(other), // Default Case
// ^^^^^^^^^ patterns `i32::MIN..=2_i32`, `4_i32..=6_i32` and `8_i32..=i32::MAX` not covered
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn move_player(num_spaces: u8) {}
}


//_________________________________________________________

fn play_with_match_underscore1() {
    let dice_roll = 9;
    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => reroll(), // _ Means Default Case
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn reroll() {}
}


//_________________________________________________________

fn play_with_match_underscore2() {
    let dice_roll = 9;

    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => (),
        // 10 => 99,

    }

    fn add_fancy_hat() 		{		}
    fn remove_fancy_hat() 	{		}
}

//_____________________________________________________________
// PATTERN MATCHING

// Type Coin
//      Range = {   Penny, Nickel, Dime, Quarter }
enum Coin {
    Penny,
    Nickel,
    Dime,
    Quarter,
}


fn value_in_cents( coin: Coin ) -> u8 {
    // match Is An Type Safe Expression
    //      It Has Return Value
    match coin {
        Coin::Penny     => 1,
        Coin::Nickel    => 5,
        Coin::Dime      => 10,
        Coin::Quarter   => 25,
    }
}

fn value_in_cents1( coin: Coin ) -> u8 {
    // match Is An Type Safe Expression
    //      It Has Return Value
    let result = match coin {
        Coin::Penny     => 1,
        Coin::Nickel    => 5,
        Coin::Dime      => 10,
        Coin::Quarter   => 25,
        // Coin::Quarter    => "Hello",
        // error[E0308]: `match` arms have incompatible types
    };

    result 
}

fn play_with_coins() {
    println!("Value : {}", value_in_cents( Coin::Penny ));
    println!("Value : {}", value_in_cents( Coin::Dime ));
    println!("Value : {}", value_in_cents( Coin::Quarter ));

    println!("Value : {}", value_in_cents1( Coin::Penny ));
    println!("Value : {}", value_in_cents1( Coin::Dime ));
    println!("Value : {}", value_in_cents1( Coin::Quarter ));
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_ipaddress_enum1");
	play_with_ipaddress_enum1();

	println!("\n\nFunction: play_with_ipaddress_enum_and_structure");
	play_with_ipaddress_enum_and_structure();

	println!("\n\nFunction: play_with_ipaddress_enum2");
	play_with_ipaddress_enum2();

	println!("\n\nFunction: play_with_ipaddress_enum3");
	play_with_ipaddress_enum3();

	println!("\n\nFunction: play_with_summation_optional");
	play_with_summation_optional();

	println!("\n\nFunction: play_with_returing_optional");
	play_with_returing_optional();

	println!("\nFunction : play_with_match_default");
	play_with_match_default();

	println!("\nFunction : play_with_match_underscore1");
	play_with_match_underscore1();

	println!("\nFunction : play_with_match_underscore2");
	play_with_match_underscore2();

	println!("\n\nFunction: play_with_coins");
	play_with_coins();
		
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

