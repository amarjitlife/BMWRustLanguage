
//_____________________________________________________________

use std::error::Error;
use minigrep::{search, search_case_insensitive};

use std::process;
use std::env;
use std::fs;

//_____________________________________________________________
//
// RUNNING CODE
//_____________________________________________________________

// $ cargo new minigrep
// $ cd minigrep
// $ cargo run

// $ cargo run -- searchstring example-filename.txt

// $ cargo run
//    Compiling minigrep v0.1.0 (file:///projects/minigrep)
//     Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.61s
//      Running `target/debug/minigrep`
// [src/main.rs:5:5] args = [
//     "target/debug/minigrep",
// ]

// $ cargo run -- needle haystack
//    Compiling minigrep v0.1.0 (file:///projects/minigrep)
//     Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.57s
//      Running `target/debug/minigrep needle haystack`
// [src/main.rs:5:5] args = [
//     "target/debug/minigrep",
//     "needle",
//     "haystack",
// ]

// $ cargo run -- the poem.txt
//    Compiling minigrep v0.1.0 (file:///projects/minigrep)
//     Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.0s
//      Running `target/debug/minigrep the poem.txt`
// Searching for the
// In file poem.txt


// $ cargo run -- frog poem.txt
// $ cargo run -- monomorphization poem.txt

// $ cargo run -- to poem.txt
// PS> $Env:IGNORE_CASE=1; cargo run -- to poem.txt

// $ cargo run > output.txt
// $ cargo run -- to poem.txt > output.txt

// $ cargo clean

// $ cargo test
//    Compiling minigrep v0.1.0 (file:///projects/minigrep)
//     Finished `test` profile [unoptimized + debuginfo] target(s) in 1.22s
//      Running unittests src/lib.rs (target/debug/deps/minigrep-9cd200e5fac0fc94)


//_____________________________________________________________

// Listing 12-6: Refactoring parse_config to return 
//		an instance of a Config struct

// use std::process;

// struct Config {
// 	query: String,
// 	file_path: String,
// }

// Listing 12-22: Calling either search or search_case_insensitive 
//		based on the value in config.ignore_case
// Filename: src/main.rs
pub struct Config {
	pub query: String,
	pub file_path: String,
	pub ignore_case: bool,
}


// Listing 12-7: Changing parse_config into Config::new

impl Config {

	#[allow(unused)]
	fn new(args: &[String]) -> Config {

// Listing 12-8: Adding a check for the number of arguments
		if args.len() < 3 {
			panic!("not enough arguments");
		}

		let query = args[1].clone();
		let file_path = args[2].clone();

		let ignore_case = env::var("IGNORE_CASE").is_ok();

		Config { query, file_path, ignore_case }
	}

// Listing 12-9: Returning a Result from Config::build
	// fn build(args: &[String]) -> Result<Config, &'static str> {
	// 	if args.len() < 3 {
	// 		return Err("not enough arguments");
	// 	}

	// 	let query = args[1].clone();
	// 	let file_path = args[2].clone();

	// 	Ok(Config { query, file_path })
	// }

// Listing 12-23: Checking for any value in an 
//		environment variable named IGNORE_CASE

	fn build(args: &[String]) -> Result<Config, &'static str> {
		if args.len() < 3 {
			return Err("not enough arguments");
		}

		let query = args[1].clone();
		let file_path = args[2].clone();

		let ignore_case = env::var("IGNORE_CASE").is_ok();

		Ok(Config {
			query,
			file_path,
			ignore_case,
		})
	}

	// $ cargo run -- to poem.txt
	// PS> $Env:IGNORE_CASE=1; cargo run -- to poem.txt

}


//_____________________________________________________________


// fn parse_config(args: &[String]) -> Config {
// 	let query = args[1].clone();
// 	let file_path = args[2].clone();

// 	Config { query, file_path }
// }


//_____________________________________________________________
// Listing 12-22: Calling either search or search_case_insensitive 
//		based on the value in config.ignore_case

// use minigrep::{search, search_case_insensitive};

fn run(config: Config) -> Result<(), Box<dyn Error>> {
	let contents = fs::read_to_string(config.file_path)?;

	let results = if config.ignore_case {
		search_case_insensitive(&config.query, &contents)
	} else {
		search(&config.query, &contents)
	};

	for line in results {
		println!("{line}");
	}

	Ok(())
}

//_____________________________________________________________

// Listing 12-24: Writing error messages to standard error 
//      instead of standard output using eprintln!

fn main() {
	let args: Vec<String> = env::args().collect();

	let config = Config::build(&args).unwrap_or_else(|err| {
		eprintln!("Problem parsing arguments: {err}");
		process::exit(1);
	});

	println!("Searching for {}", config.query);
	println!("In file {}", config.file_path);
	println!("Ignore Case {}", config.ignore_case);

	if let Err(e) = run(config) {
		eprintln!("Application error: {e}");
		process::exit(1);
	}
}


// $ cargo run > output.txt


//_____________________________________________________________

// The args Function and Invalid Unicode
// Note that std::env::args will panic if any argument contains 
//		invalid Unicode. If your program needs to accept arguments
//		containing invalid Unicode, use std::env::args_os instead. 
//		That function returns an iterator that produces OsString 
//		values instead of String values. We’ve chosen to use 
//		std::env::args here for simplicity because OsString values 
//		differ per platform and are more complex to work with than 
//		String values.

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

