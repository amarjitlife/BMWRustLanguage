

//_____________________________________________________________


// Writing Code to Pass the Test
// Currently, our test is failing because we always return an empty vector. 
//	To fix that and implement search, our program needs to follow these steps:

// 1. Iterate through each line of the contents.
// 2. Check whether the line contains our query string.
// 3. If it does, add it to the list of values we’re returning.
// 4. If it doesn’t, do nothing.
// 5. Return the list of results that match.


// Listing 12-19: Storing the lines that match so that we can return them
pub fn search<'a>(query: &str, contents: &'a str) -> Vec<&'a str> {
	let mut results = Vec::new();

	for line in contents.lines() {
		if line.contains(query) {
			results.push(line);
		}
	}

	results
}


// $ cargo test
//    Compiling minigrep v0.1.0 (file:///projects/minigrep)
//     Finished `test` profile [unoptimized + debuginfo] target(s) in 1.22s
//      Running unittests src/lib.rs (target/debug/deps/minigrep-9cd200e5fac0fc94)

// $ cargo run -- frog poem.txt
// $ cargo run -- monomorphization poem.txt

//_____________________________________________________________

// Listing 12-21: Defining the search_case_insensitive function 
//		to lowercase the query and the line before comparing them
// Filename: src/lib.rs


pub fn search_case_insensitive<'a>(
	query: &str,
	contents: &'a str,
) -> Vec<&'a str> {
	let query = query.to_lowercase();
	let mut results = Vec::new();

	for line in contents.lines() {
		if line.to_lowercase().contains(&query) {
			results.push(line);
		}
	}

	results
}

// $ cargo test


//_____________________________________________________________

// Working with Environment Variables

// Listing 12-20: Adding a new failing test for 
//		the case-insensitive function we’re about to add
// Filename: src/lib.rs

#[cfg(test)]
mod tests {
	use super::*;

	#[test]
	fn case_sensitive() {
		let query = "duct";
		let contents = "\
Rust:
safe, fast, productive.
Pick three.
Duct tape.";

		assert_eq!(vec!["safe, fast, productive."], search(query, contents));
	}

	#[test]
	fn case_insensitive() {
		let query = "rUsT";
		let contents = "\
Rust:
safe, fast, productive.
Pick three.
Trust me.";

		assert_eq!(
			vec!["Rust:", "Trust me."],
			search_case_insensitive(query, contents)
		);
	}
}


//_____________________________________________________________

// Listing 12-15: Creating a failing test for the search function 
//		for the functionality we wish we had

// #[cfg(test)]
// mod tests {
// 	use super::*;

// 	#[test]
// 	fn one_result() {
// 		let query = "duct";
// 		let contents = "\
// Rust:
// safe, fast, productive.
// Pick three.";

// 		assert_eq!(vec!["safe, fast, productive."], search(query, contents));
// 	}
// }

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________




