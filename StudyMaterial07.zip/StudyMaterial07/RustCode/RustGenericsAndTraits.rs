#![allow(unused)]


//_____________________________________________________________
// DRY PRACTICE
//		Don't Repeat Yourself!

fn play_with_largest1() {
	let number_list = vec![34, 50, 25, 100, 65];
	let mut largest = &number_list[0];

	for number in &number_list {
		if number > largest {
			largest = number;
		}
	}

	println!("The largest number is {largest}");


	let number_list = vec![102, 34, 6000, 89, 54, 2, 43, 8];
	let mut largest = &number_list[0];

	for number in &number_list {
		if number > largest {
			largest = number;
		}
	}

	println!("The largest number is {largest}");
}


//_____________________________________________________________

// Algorithm Is Invariant
//		What Is Changing?
//			 Type Of Argumennts And Return Type
fn largest_i32(list: &[i32]) -> &i32 {
	let mut largest = &list[0];

	for item in list {
		if item > largest {
			largest = item;
		}
	}

	largest
}

// Algorithm Is Invariant
//		What Is Changing?
//			 Type Of Argumennts And Return Type
fn largest_char(list: &[char]) -> &char {
	let mut largest = &list[0];

	for item in list {
		if item > largest {
			largest = item;
		}
	}

	largest
}

fn play_with_largest2() {
	let number_list = vec![34, 50, 25, 100, 65];

	let result = largest_i32( &number_list );
	println!("The largest number is {result}");

	let number_list = vec![102, 34, 6000, 89, 54, 2, 43, 8];
	let result = largest_i32( &number_list );
	println!("The largest number is {result}");

	let char_list = vec!['y', 'm', 'a', 'q'];

	let result = largest_char( &char_list );
   // |                  -------  ^^^^^^^^^^ expected `&[i32]`, found `&Vec<char>`
	println!("The largest char is {result}");
}


//_____________________________________________________________

// Algorithm Is Invariant
//		What Is Changing?
//			 Type Of Argumennts And Return Type

// fn largest< T >( list: &[ T ] ) -> &T {

// error[E0369]: binary operation `>` cannot be applied to type `&T`
//   --> RustGenericsAndTraits.rs:96:11
//    |
// 96 |         if item > largest {
//    |            ---- ^ ------- &T
//    |            |
//    |            &T
//    |
// help: consider restricting type parameter `T` with trait `PartialOrd`
//    |
// 92 | fn largest<T: std::cmp::PartialOrd>( list: &[ T ] ) -> &T {
//    |             ++++++++++++++++++++++



// T Can Be Any Type Provided It Follows Upper Bound
//		We Write After T Followed By : Upper Bound Type
//		T : Upper Bound Type
// 		Hence T Can Be Any Type Provided It Implemnents PartialOrd

// Generic Function
// <T> Means T To Be Used As Type Placeholder
//		Hence T Type Placeholder Will Get Substituted With Type
//		It Will Be Sustituted At Compile Time Based On Usage

fn largest< T : std::cmp::PartialOrd >( list: &[ T ] ) -> &T {
	let mut largest = &list[0];

	for item in list {
		if item > largest {
		//    |            ---- ^ ------- &T
		// help: consider restricting type parameter `T` with trait `PartialOrd`
			largest = item;
		}
	}

	largest
}

/*
// Compiler Will Generate Following Code Based On Tempalate/Generics
// <T> Means T To Be Used As Type Placeholder
//		Hence T Type Placeholder Will Get Substituted With Type
//		It Will Be Sustituted At Compile Time Based On Usage

fn largest_i32( list: &[ i32 ] ) -> &i32 {
	// Algorithm Is Invariant and Remains Same
}

fn largest_char( list: &[ char] ) -> &char {
	// Algorithm Is Invariant and Remains Same
}

fn largest_i64( list: &[ f64 ] ) -> &f64 {
	// Algorithm Is Invariant and Remains Same
}

fn largest_str( list: &[ str ] ) -> &str {
	// Algorithm Is Invariant and Remains Same
}
*/

// Generics/Template
//		Template Directive To Compiler
//		It's A Tempalte To Generate Code

fn play_with_largest3() {
	let number_list = vec![34, 50, 25, 100, 65]; 	// vec![ i32 ]
	let result = largest( &number_list ); 			// &vec![ i32 ] Hence T Should i32
	println!("The largest number is {result}");

	let number_list = vec![102, 34, 6000, 89, 54, 2, 43, 8];
	let result = largest( &number_list );
	println!("The largest number is {result}");

	let char_list = vec!['y', 'm', 'a', 'q'];
	let result = largest( &char_list );
	println!("The largest char is {result}");

	let number_list = vec![34.3, 50.5, 25.25, 100.11, 65.90];
	let result = largest( &number_list );
	println!("The largest number is {result}");

	let names_list = vec![ "Ram", "Shyam", "Abdul", "Neeraj", "Swati"];
	let result = largest( &names_list );
	println!("The largest number is {result}");

}

//_____________________________________________________________

// Generic Structure
// <T> Means T To Be Used As Type Placeholder
//		Hence T Type Placeholder Will Get Substituted With Type
//		It Will Be Sustituted At Compile Time Based On Usage

// In Following Defintion x And y Both Are Going To Of Same Type
#[derive(Debug)]
struct Point1< T > {
	x: T, 
	y: T,
}


// In Following Defintion x And y Both Are Going To Of Same Type
#[derive(Debug)]
struct Point2< T, U > {
	x: T, 
	y: U,
}

#[derive(Debug)]
struct Point3< T > {
	x: T, 
	y: T,
}

impl< T > Point3< T > {
	fn x( &self ) -> &T {
		&self.x
	}

	fn tuple( &self ) -> (&T, &T) {
		println!("Implementation Called For Any <T>");
		let Point3{ x, y } = self; 
		let point_tuple = ( x, y );

		point_tuple
	}
}

impl Point3< f32 > {
	fn distance_from_origin( &self ) -> f32 {
		println!("Special Implementation Called For f32");
		( self.x.powi( 2 ) + self.y.powi( 2 ) ).sqrt()
	}
}

fn play_with_generic_structure1() {
	let integer_point 	= Point1{ x : 20, y: 20 };
	let floating_point 	= Point1{ x : 20.20, y: 30.3 };

	let integer_floating_point = Point2{ x : 20, y: 20.22 };
	let floating_integer_point = Point2{ x : 30.33, y: 30 };

	println!("Point1 : {:?}", integer_point);
	println!("Point1 : {:?} {:?}", integer_point.x, integer_point.y);

	println!("Point1 : {:?}", floating_point);
	println!("Point1 : {:?} {:?}", floating_point.x, floating_point.y);

	println!("Point2 : {:?}", integer_floating_point);
	println!("Point2 : {:?} {:?}", integer_floating_point.x, integer_floating_point.y);

	println!("Point2 : {:?}", floating_point);
	println!("Point2 : {:?} {:?}", floating_integer_point.x, floating_integer_point.y);

	let integer_point 	= Point3{ x : 20, y: 20 };
	let floating_point 	= Point3{ x : 20.20, y: 30.3 };

	println!("Point3 : {:?}", integer_point);
	println!("Point3 : {:?}", floating_point);

	println!("Value: {:?} {:?}", integer_point.x, integer_point.x() );
	println!("Value: {:?} {:?}", floating_point.x, floating_point.x() );

	println!("Point3 : {:?}", integer_point.tuple() );
	println!("Point3 : {:?}", floating_point.tuple() );

	let point_f32 	= Point3{ x : 333.80f32, y: 444.55f32 };
	println!("Point3 : {:?}", point_f32);

	println!("Point3 : {:?}", point_f32.x() );
	println!("Point3 : {:?}", point_f32.tuple() );
	println!("Point3 : {:?}", point_f32.distance_from_origin() );
}


//_____________________________________________________________

/*
#[derive(Debug)]
struct Point33< T, U > {
	x: T, 
	y: U,
}


#[derive(Debug)]
struct Point4< T, U > {
	x: T, 
	y: U,
}


impl< T, U > Point4< T, U > {
	fn x( &self ) -> &T {
		&self.x
	}

	fn tuple( &self ) -> (&T, &U) {
		println!("Implementation Called For Any <T>");
		let Point4{ x, y } = self; 
		let point_tuple = ( x, y );

		point_tuple
	}

	fn mixup<V, W>( self, other: Point33<T, U> ) -> Point4<T, U> {
		Point4 {
			x: self.x,
			y: other.y,
		}
	}
}

fn play_with_generic_structure2() {
	let p1 	= Point4{ x : "Ding", y: 99.99 };
	let p2 	= Point33{ x : , y: 44.44 };
	
	let p3 = p1.mixup( p2 );

	println!("Point4 : {:?}", p1);
	println!("Point4 : {:?}", p2);
	println!("Point4 : {:?}", p3);

	println!("Point4 : {:?} {:?}", p1.x, p1.y);
	println!("Point4 : {:?} {:?}", p2.x, p2.y);
	println!("Point4 : {:?} {:?}", p3.x, p3.y);
}

*/


//_____________________________________________________________

#[derive(Debug)]
struct Point4<X1, Y1> {
	x: X1,
	y: Y1,
}

impl<X1, Y1> Point4<X1, Y1> {

	// Member Function Can Have Different Type Place Holder
	// 1. Mixing Different Types Of Data
	// 2. Type Conversion 
	fn mixup<X2, Y2>(self, other: Point4<X2, Y2>) -> Point4<X1, Y2> {
		Point4 {
			x: self.x,
			y: other.y,
		}
	}
}

fn play_with_generic_structure2() {
	let p1 = Point4 { x: 5, y: 10.4 };
	let p2 = Point4 { x: "Hello", y: 'c' };

	let p3 = p1.mixup(p2);

	println!("p3.x = {}, p3.y = {}", p3.x, p3.y);
}

//_____________________________________________________________

//In Rust, the reason you write type parameters twice—
//		as in impl<T> Point5<T>—is 
//		because the <T> after impl declares a generic parameter, 
//		while the <T> after Point5 uses it.

#[allow(unused)]
#[derive(Debug)]
struct Point5<T> {
    x: T,
    y: T,
}

// 1. Generic implementation: Works for ANY type T
#[allow(unused)]
impl<T> Point5<T> {
    fn x(&self) -> &T { &self.x }
}

// 2. Concrete implementation: ONLY works for Point<f32>
#[allow(unused)]
impl Point5<f32> {
    fn distance_from_origin(&self) -> f32 {
        (self.x.powi(2) + self.y.powi(2)).sqrt()
    }
}


//_____________________________________________________________
//
// Generic Enums
//______________________________________________________________

#[allow(unused)]
enum Option<T> {
    Some(T),
    None,
}

#[allow(unused)]
enum Result<T, E> {
    Ok(T),
    Err(E),
}

//_____________________________________________________________
//
// +++++  EXPERIMENT ABOVE CODE AND RAISE YOUR HANDS MOMENT DONE!!!
//_____________________________________________________________


//_____________________________________________________________
//
// TRAITS
//_____________________________________________________________

// Traits Enforces Contract Implementing Types
trait Summary {
	// Method Declaration With Method Signature
	fn summarize( &self ) -> String; 
}

#[derive(Debug)]
struct NewsArticle {
	headline: String,
	location: String,
	author: String,
	content: String,
}

// NewsArticle Implements Trait Summary
//		It Must Follow Contract Enforced By Summary
impl Summary for NewsArticle {
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^ missing `summarize` in implementation
	fn summarize( &self ) -> String {
		format!("{}, by {}, {}", self.headline, self.author, self.location)
	}

}


#[derive(Debug)]
struct Tweet {
	username: String,
	content: String,
	reply: String,
	retweet: String,
}

// Tweet Implements Trait Summary
//		It Must Follow Contract Enforced By Summary
impl Summary for Tweet {
	fn summarize( &self ) -> String {
		format!("{}: {}", self.username, self.content)
	}

}

//________________________________

// Following Both Functions Are Equivalent

// Polymorphic Function :: Using Trait Argument
//		We Can Pass Any Type Of Object Which Implements Summary Trait
fn notify1( item: &impl Summary ) {
	println!("Breaking Thing! :: {:?}", item.summarize() );
}

// Polymorphic Function :: Using Generic Argument
//		We Can Pass Any Type Of Object Which Implements Summary Trait
fn notify1_again< T: Summary >( item: &T ) {
	println!("Breaking Thing! :: {:?}", item.summarize() );
}

fn notify2( item1: &impl Summary, item2: &impl Summary ) {
	println!("Breaking Thing! :: {:?}", item1.summarize() );
	println!("Breaking Thing! :: {:?}", item2.summarize() );
}

fn notify3( item: &( impl Summary + Display ) ) {
	println!("Breaking Thing! :: {:?}", item.summarize() );
	println!("Breaking Thing! :: {:?}", item.summarize() );
}

fn notify3_again< T : Summary + Display >( item: &T ) {
	println!("Breaking Thing! :: {:?}", item.summarize() );
	println!("Breaking Thing! :: {:?}", item.summarize() );
}

// pub trait Display {
//     // Required method
//     fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), Error>;
// }

// Reference: Display Trait Defined In Rust
// https://doc.rust-lang.org/std/fmt/trait.Display.html

//________________________________


fn play_with_traits() {
	let article = NewsArticle {
		headline: "String Data....".to_string(),
		location: "String Data....".to_string(),
		author: "String Data....".to_string(),
		content: "String Data....".to_string(),		
	};

	println!("News: {:?}", article);
	println!("News Content: {:?}", article.content);
	println!("Summary: {:?}", article.summarize() );

	let tweet = Tweet {
		username: "String Data....".to_string(),
		content: "String Data....".to_string(),		
		reply: "String Data....".to_string(),
		retweet: "String Data....".to_string(),
	};

	println!("Tweet: {:?}", tweet);
	println!("Summary: {:?}", tweet.summarize() );

	println!("Tweet Reply: {:?}", tweet.reply);
	println!("Tweet Retweet: {:?}", tweet.retweet);

	notify1( &article );
	notify1( &tweet );

	notify1_again( &article );
	notify1_again( &tweet );

}


//_____________________________________________________________
// Following Both Functions Are Equivalent

use std::fmt::Display;
use std::fmt::Debug;

fn some_function< T: Display + Clone, U: Clone + Debug >( t : &T, u: &U ) -> i32 {
	999
}

fn some_function_again< T, U>( t : &T, u: &U ) -> i32 
where
	T: Display + Clone,
	U: Clone + Debug,
{
	999
}


//_____________________________________________________________

struct Pair< T > {
	x: T,
	y: T,
}


impl< T > Pair< T > {
	fn new( x: T, y: T ) -> Self {
		Self { x, y }
	}
}

impl< T : Display + PartialOrd >  Pair< T > {
	fn cmp_display( &self ) {
		if self.x >= self.y {
			println!("The Largest Member: {}", self.x );
		} else {
			println!("The Largest Member: {}", self.y );
		}
	}
}


//_____________________________________________________________

// `Centimeters`, a tuple struct that can be compared
#[derive(PartialEq, PartialOrd)]
struct Centimeters(f64);

// `Inches`, a tuple struct that can be printed
#[derive(Debug)]
struct Inches(i32);

impl Inches {
	fn to_centimeters(&self) -> Centimeters {
		let &Inches(inches) = self;

		Centimeters(inches as f64 * 2.54)
	}
}

// `Seconds`, a tuple struct with no additional attributes
#[derive(Debug, PartialEq)]
struct Seconds(i32);

//_____________________________________________________________

fn play_with_derived_traits() {
	let _one_second = Seconds(1);

	// Error: `Seconds` can't be printed; 
	//  it doesn't implement the `Debug` trait
	//println!("One second looks like: {:?}", _one_second);
	// TODO ^ Try uncommenting this line

	// Error: `Seconds` can't be compared; 
	//      it doesn't implement the `PartialEq` trait
	//let _this_is_true = (_one_second == _one_second);
	// TODO ^ Try uncommenting this line

	let foot = Inches(12);

	println!("One foot equals {:?}", foot);

	let meter = Centimeters(100.0);

	let cmp =
		if foot.to_centimeters() < meter {
			"smaller"
		} else {
			"bigger"
		};

	println!("One foot is {} than one meter.", cmp);
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________


fn main() {
	println!("\n\nFunction: play_with_largest1");
	play_with_largest1();

	println!("\n\nFunction: play_with_largest2");
	play_with_largest2();

	println!("\n\nFunction: play_with_largest3");
	play_with_largest3();

	println!("\n\nFunction: play_with_generic_structure1");
	play_with_generic_structure1();

	println!("\n\nFunction: play_with_generic_structure2");
	play_with_generic_structure2();

	println!("\n\nFunction: play_with_traits");
	play_with_traits();

	println!("\n\nFunction: play_with_derived_traits");
	play_with_derived_traits();
	
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

