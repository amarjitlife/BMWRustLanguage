
use std::fs::File;
// use std::error::Error;
use std::io::ErrorKind;
use std::io::{self, Read};

//_____________________________________________________________

fn play_with_panic() {
	// panic!("Crashing Code By Calling panic");

	let numbers = vec![10, 20, 30];
	println!("Numbers : {:?}", numbers);
	println!("Number At Index {:?} : {:?}", 1, numbers[1]);

	// let _value = numbers[9];
	// index out of bounds: the len is 3 but the index is 9
}


//_____________________________________________________________

// In Rust
//		Definition Of Option Type As Follows:

// pub enum Option<T> {
// 		// Representing Invalid Value i.e. Unhappy Case
// 		None,
// 		// Valid Value Wrapped Inside Some  i.e. Happy Case
// 		//		i.e. Treat Some As Bucket Having Valid Value
// 		Some(T),    
// }

// Option Types Are Used For Representing
//		Happy and Unhappy Cases
//		i.e. Valid Value Or Invalid Value

// Creating Function Returning Option Type
// Design Choice 03
fn summation( a: i32, b: i32 ) -> Option<i32> {
	let min_val = i32::MIN;
	let max_val = i32::MAX;

	let result: Option<i32>; // = None;

	if ( b > 0 && a > max_val -b ) || ( b < 0 && a < min_val - b ) { 
		// Error : Overflow/Underflow
		result = None;  		// Invalid Value i.e. Unhappy Case
	} else {
		result = Some( a + b ) 	// Valid Value i.e. Happy Case
	}

	result // Expression It's Return Value Of Function
}


fn play_with_summation_optional() {
	let a = 888888;
	let b = 111;

	// What Is The Type Of result Variable?
	// 		It's Type Of Option<i32>
	//			Either None Or Some( value )
	let result = summation( a, b );
	println!("Result : {:?}", result);

	// Pattern Mathcing Using match Construct
	match result {
		Some(value) 	=> println!("Calculated Sum : {:?}", value),
		None 			=> println!("Error : Summation Is Invalid For Given Values: {} {}", a, b),
	}

	let a = 2147483647;
	let b = 111;

	// What Is The Type Of result?
	//		Option<i32>
	let result = summation( a, b );
	println!("Result : {:?}", result);

	// Pattern Mathcing Using match Expression
	//		match Expression Have Return Value
	//			Return Value Depends On Which Arm Matched
	//			Match Arm Mapped Block Value Will Become Return Value Of match Expression
	//				Mapped Block Is Followed By =>  

	let something = match result {
		Some(value) 	=> { 
			println!("Calculated Sum : {:?}", value);
			1 // Using To Show match Returns Value
		}
		None 			=> {
			println!("Error : Summation Is Invalid For Given Values: {} {}", a, b);
			0 // Using To Show match Returns Value
		}
	};

	println!("Something : {:?}", something);
}


//_____________________________________________________________

// Result Type
// enum is defined as having two variants, Ok and Err, 

// Option Type Is Special Case Of Result Type
//		In Result Type
//			Happy Case 		i.e. Ok ( value ) // Valid Value
//			Unhappy Case 	i.e. Err( erorr ) // Invalid Value With Reason error
// enum Result<T, E> {
// 		Ok(T),
// 		Err(E),
// }


fn play_with_error_handling1() {

	// let greeting_file_result: () = File::open("Hello.txt");
	// let greeting_file_result: Result<File, Error> = File::open("GreetingFile.txt");
	// let file_name = "GreetingNonExistingFile.txt".to_string();
	let file_name = "GreetingExistingFile.txt".to_string();
	let greeting_file_result = File::open( &file_name );
	println!("Result : {:?}", greeting_file_result );

	let greeting_file = match greeting_file_result {
		Ok( ref file ) 		=> file,
		Err( error )		=> panic!("{:?} {:?}", file_name, error),
	};

	println!("Result : {:?}", greeting_file );

}

// The return type of File::open is a Result<T, E> . The generic parameter T has 
// been filled in by the implementation of File::open with the type of 
//	the success value, std::fs::File, which is a file handle. 
//	The type of E used in the error value is std::io::Error

// Note that, like the Option enum, the Result enum and its variants have been brought into
// scope by the prelude, so we don’t need to specify Result:: before the Ok and Err
// variants in the match arms.


//_____________________________________________________________


// Matching Different Kinds Of Errors
//		Home Work: Write Flat Code Rather Than Nested Code
fn play_with_error_handling2() {
	let file_name = "GreetingExistingFile.txt".to_string();
	let greeting_file_result = File::open( &file_name );
	println!("Result : {:?}", greeting_file_result );

	let greeting_file = match greeting_file_result {
		Ok( file ) 		=> file,
		Err( error )	=> match error.kind() {
								ErrorKind::NotFound => 	match File::create( &file_name ) {
									Ok( file_created ) 			=> file_created,
									Err( e )	=> panic!("{:?} Creation File Failed : {e:}", 
																file_name),
					},
					_ 	=> { 
						panic!("{:?} Opening File Failed: {:?}", file_name, error);
					}
				},
			};

	println!("Result : {:?}", greeting_file );

}

//_____________________________________________________________

// Creating Function Returning Result Type

fn read_username_from_file() -> Result<String, io::Error> {
	let username_file_result = File::open("HelloFile.txt");

	let mut username_file = match username_file_result {
		Ok( file ) 		=> file,
		Err( error )	=> return Err( error ), // Error Proporation :: Same/Different Error
	};

	let mut username = String::new();

	// Last Expression In Function : It's Return Value Of Function
	match username_file.read_to_string( &mut username ) {
		Ok( _ ) 		=> 	Ok( username ),
		Err( error )	=> 	Err( error ),
	}
}

fn play_with_read_username_from_file() {
	
	let result = read_username_from_file();
	println!("Result : {:?}", result );
}

// To Test Code
//		In Same Directory Where This Code File Exists 
//		1. Create helloFile.txt 
//		2. Add Following Text To File
//			 	Gabbar Singh

// Now Run Code
// Function: play_with_read_username_from_file
// Result : Ok("Gabbar Singh\n")

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_panic");
	play_with_panic();

	println!("\n\nFunction: play_with_summation_optional");
	play_with_summation_optional();

	println!("\n\nFunction: play_with_error_handling1");
	play_with_error_handling1();

	println!("\n\nFunction: play_with_error_handling2");
	play_with_error_handling2();

	println!("\n\nFunction: play_with_read_username_from_file");
	play_with_read_username_from_file();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

