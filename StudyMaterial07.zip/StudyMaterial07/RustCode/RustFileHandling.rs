
use std::fs::File;
use std::io::prelude::*;
use std::path::Path;
use std::fs::OpenOptions;
use std::fs::read_to_string;
use std::io::{self, BufRead};

//_____________________________________________________________

// File I/O
// The File struct represents a file that has been opened (it wraps a file descriptor), 
//		and gives read and/or write access to the underlying file.

// Since many things can go wrong when doing file I/O, 
//		all the File methods return the io::Result<T> type, 
//		which is an alias for Result<T, io::Error>.

// This makes the failure of all I/O operations explicit. 
//		Thanks to this, the programmer can see all the failure paths, 
//		and is encouraged to handle them in a proactive manner.


//_____________________________________________________________

// use std::fs::File;
// use std::io::prelude::*;
// use std::path::Path;

fn play_with_file_opening_and_reading() {
    // Create a path to the desired file
    // let path = Path::new("HelloFileNonExisting.txt");
    let path = Path::new("HelloFileExisiting.txt");
    let display = path.display();

    // Open the path in read-only mode, returns `io::Result<File>`
    let mut file = match File::open(&path) {
        Err(why) => panic!("couldn't open {}: {}", display, why),
        Ok(file) => file,
    };

    // Read the file contents into a string, returns `io::Result<usize>`
    let mut s = String::new();
    match file.read_to_string(&mut s) {
        Err(why) => panic!("couldn't read {}: {}", display, why),
        Ok(_) => print!("{} contains:\n{}", display, s),
    }

    // `file` goes out of scope, and the "hello.txt" file gets closed
}

//_____________________________________________________________

static LOREM_IPSUM: &str =
    "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
";

// use std::fs::File;
// use std::io::prelude::*;
// use std::path::Path;

fn play_with_file_creations() {
    let path = Path::new("LoremIpsumFile.txt");
    let display = path.display();

    println!("Path: {:?}", path);

    // Open a file in write-only mode, returns `io::Result<File>`
    let mut file = match File::create(&path) {
        Err(why) => panic!("couldn't create {}: {}", display, why),
        Ok(file) => file,
    };

    // Write the `LOREM_IPSUM` string to `file`, returns `io::Result<()>`
    match file.write_all(LOREM_IPSUM.as_bytes()) {
        Err(why) => panic!("couldn't write to {}: {}", display, why),
        Ok(_) => println!("successfully wrote to {}", display),
    }

	// The OpenOptions struct can be used to configure how a file is opened.
	// use std::fs::OpenOptions;

	let file = OpenOptions::new()
	            .read(true)
	            .write(true)
	            .create(true)
	            .open("TestFile.txt");
    println!("File Created: {:?}", file);
}


//_____________________________________________________________

// use std::fs::read_to_string;

fn read_lines(filename: &str) -> Vec<String> {
    let mut result = Vec::new();

    for line in read_to_string(filename).unwrap().lines() {
        result.push(line.to_string())
    }

    result
}

fn play_with_file_reading_lines() {

    let filename = "LoremIpsumFile.txt";

    let lines = read_lines( filename );
    println!("Read Content From File: {filename}...\n");

    let mut line_count = 1;
    for line in lines {
	    println!( "{:?} {:?}", line_count, line );
	    line_count += 1;
    }
}

//_____________________________________________________________

// use std::fs::read_to_string;

fn read_lines_again(filename: &str) -> Vec<String> {
    read_to_string(filename)
        .unwrap()  			// panic on possible file-reading errors
        .lines()  			// split the string into an iterator of string slices
        .map( String::from )  // make each slice into a string
        .collect()  		// gather them together into a vector
}


fn play_with_file_reading_lines_again() {

    let filename = "LoremIpsumFile.txt";

    let lines = read_lines_again( filename );
    println!("Read Content From File: {filename}...\n");

    let mut line_count = 1;
    for line in lines {
	    println!( "{:?} {:?}", line_count, line );
	    line_count += 1;
    }
}

//_____________________________________________________________

// A more efficient approach
// Here we pass ownership of the open File to a BufReader struct. 
// 	BufReader uses an internal buffer to reduce intermediate allocations.

// We also update read_lines to return an iterator instead of allocating 
//		new String objects in memory for each line.

//_____________________________________________________________

// use std::fs::File;
// use std::io::{self, BufRead};
// use std::path::Path;


// The output is wrapped in a Result to allow matching on errors.
// Returns an Iterator to the Reader of the lines of the file.

fn read_lines_better<P>(filename: P) -> io::Result<io::Lines<io::BufReader<File>>>
where P: AsRef<Path>, {
    let file = File::open(filename)?;
    Ok(io::BufReader::new(file).lines())
}

fn play_with_file_reading_lines_better() {
    let filename = "LoremIpsumFile.txt";
    println!("Read Content From File: {filename}...\n");

    if let Ok(lines) = read_lines_better( filename ) {
        // Consumes the iterator, returns an (Optional) String
       
        let mut line_count = 1;
	    for line in lines.map_while( Result::ok ) {
	    	println!( "{:?} {:?}", line_count, line );
	    	line_count += 1;
        }
    }
}


//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fn main() {
	println!("\n\nFunction: play_with_file_opening_and_reading");
	play_with_file_opening_and_reading();

	println!("\n\nFunction: play_with_file_creations");
	play_with_file_creations();

	println!("\n\nFunction: play_with_file_reading_lines");
	play_with_file_reading_lines();

	println!("\n\nFunction: play_with_file_reading_lines_again");
	play_with_file_reading_lines_again();

	println!("\n\nFunction: play_with_file_reading_lines_better");
	play_with_file_reading_lines_better();

	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");
	// println!("\n\nFunction: ");	
}

