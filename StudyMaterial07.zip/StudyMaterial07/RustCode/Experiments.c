
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

//_____________________________________________________________

void playWithTypes() {
	int number = 9;

	printf("\nValue: %d", number);
	number =  999;
	printf("\nValue: %d", number);

	int numberAgain;
	printf("\nValue: %d", numberAgain);

	int condition = -10;
	// int number1 = if (condition) { 55; } else { 99; }
	// printf("\nValue: %d", number1);	

	// In C/C++
	//		Expression Can Be Anything Which Evaluated To int Value
	//		Non-Zero int Value Treated As True
	//		Zero int Value Treated As False

	// if ( Expression ) {} else { }
	
	if (condition) { 55; } else { 99; }


	int a = 10;
	// int a = 20; Compilation Error

	printf("\nValue: %d", a);
	{ // Nested Scope 1

		// Nested Scope 1 Will Shadow Outer Scope
		// Hence Local Variable Definiton Always Takes Precedence
		int a = 11;
		printf("\nValue: %d", a);
		
		{ // Nested Scope 2
			// Nested Scope 2 Will Shadow Nested Scope 1 Outer Scope
			// Hence Local Variable Definiton Always Takes Precedence
			int a  = 999;
			printf("\nValue: %d", a);

		}
		printf("\nValue: %d", a);

	}
	printf("\nValue: %d", a);
}


//_____________________________________________________________

// BAD DESIGN
int sum( int a, int b ) {
	return a + b;
}

// BAD DESIGN
// long sum( int a, int b ) {
// 	return a + b;
// }

// BAD DESIGN
// long long sum( long a, long b ) {
// 	return a + b;
// }

// BAD DESIGN
// long long sum( long long a, long long b ) {
// 	return a + b;
// }

void playWithSum() {
	int a = 2147483647;
	int b = 111;

	int result = 0;

	result = sum(a, b);
	printf("\nResult : %d", result);
}

// Function: playWithSum
// Result : -2147483538

//_____________________________________________________________
// int authentication( char[] username, char[] password ) {
// int authentication() {
// 	char username[] = username;
// 	char password[] = password;

void playWithArrays() {

	char greeting[] = "Good Morning!!!";

	printf("\n");
	for( int i = 0 ; i < 15 ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	printf("\n");
	for( int i = 0 ; i < 15 ; i++ ) {
		printf(" %c ", *(greeting + i) );
	}

	printf("\n");
	for( int i = 0 ; i < 20 ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	printf("\n");
	for( int i = -10 ; i < 20 ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	printf("\n");
	for( int i = 0 ; i < 25 ; i++ ) {
		printf(" %c ", *(greeting + i) );
	}

	printf("\n");
	for( int i = -10 ; i < 25 ; i++ ) {
		// if ( start_index <= i < end_index ) {
			printf(" %c ", *(greeting + i) );
		// }
		// else {

		// }
	}

	// Vulnerability
}


// C/C++ Language Design Principle
//		Design Towards Performance
//		You Should Not Pay For It If You Are Not Using It

//_____________________________________________________________

void playWithArraysAgain() {
	// Array Name Is Contant Pointer To First Member In Contigous Memory
	int numbers[] = {10, 20, 30, 44, 99, 77 };

	// numbers++; 		// Invalid number = number + 1;
	// error: lvalue required as increment operand

	numbers + 1; 	// Valid

	printf("\n");
	for (int index = 0 ; index < 6 ; index++ ) {
		printf(" %d ", numbers[index]);
	}

	// In C/C++ Pointers Are Unsafe Pointer
	//		Unsafe Pointers Are Also Called Raw Pointer
	int *pointer = numbers;

	printf("\n");
	for (int index = 0 ; index < 6 ; index++ ) {
		printf(" %d ", *( pointer + index ) );
	}

	printf("\n");
	for (int index = 0 ; index < 6 ; index++ ) {
		printf(" %d ", *( pointer++ ) );
	}

	// Is It Possible To Do In C/C++;
	pointer++;
	printf(" %d ", *pointer );

}

//_____________________________________________________________
// Sum Design 00

// Function Can Return Only 1 Value
//		Either Return Valid Result Or Error Code

int sum_design0(int a, int b) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
    	printf("\nError: Overflow/Underflow...");
    	exit( 1 );
    }
    
    int result = a + b;
    return result; 
}

//_____________________________________________________________
// Sum Design 01

// Function Can Return Only 1 Value
//		Either Return Valid Result Or Error Code

int sum_design1(int a, int b, int *error) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        *error = 1; // overflow or underflow
    }
    
    int result = a + b;
    *error = 0;
    return result; 
}

//_____________________________________________________________
// Sum Design 02

int sum_design2(int a, int b, int *result) {  
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
        return 0; // overflow or underflow
    }
    
    *result = a + b;
    return 1; // success
}


//_____________________________________________________________
// Sum Design 03

// #include <limits.h>
typedef struct OptionalInt {
	int value;
	int valid;
} Optional;

Optional sum_design3(int a, int b) {  
    Optional result = { 0, 0 };
    if ((b > 0 && a > INT_MAX - b) ||
        (b < 0 && a < INT_MIN - b)) {
	    result.value = a + b;
    	result.valid = 0; // Invalid Value
    } else {
	    result.value = a + b;
    	result.valid = 1; // Valid Value
    }
    return result;   
}

void play_with_sum_design3() {
	int a = 54849849;
	int b = 1111;

	Optional result = sum_design3( a, b );

	if ( result.valid ) { printf("\n Result Value: %d", result.value ); } 
	else { printf("\nNot A Valid Result Received..."); }
}

//_____________________________________________________________

enum Coin {
    Penny,
    Nickel,
    Dime,
    Quarter
};

unsigned char value_in_cents( enum Coin coin ) {
    // C/C++/Java
    // switch Is A Statement
    unsigned char value = 0;

    switch( coin ) { // Expression It's Return Value Of The Function
        case Penny:  
        	value = 1; 
        	break;
        case Nickel:   
        	value = 5; 
        	break;
        case Dime:
        	value = 10; 
        	break;
        case Quarter:
        	value = 25; 
        	break;
    }

    return value;
}

unsigned char value_in_cents1( enum Coin coin ) {
    // C/C++/Java
    // switch Is A Statement
    unsigned char value = 0;

    switch( coin ) { // Expression It's Return Value Of The Function
        case Penny:  
        	value = 1; 
        	break;
        case Nickel:   
        	value = 5; 
        	break;
        // case Dime:
        // 	value = 10; 
        // 	break;
        // case Quarter:
        // 	value = 25; 
        // 	break;
        default:  // Optional Case
        	value = 99;
    }

    return value;
}

void play_with_coins() {
    printf("\nValue : %d", value_in_cents( Penny ));
    printf("\nValue : %d", value_in_cents( Nickel ));
    printf("\nValue : %d", value_in_cents( Dime ));
    printf("\nValue : %d", value_in_cents( Quarter ));

    printf("\nValue : %d", value_in_cents1( Penny ));
    printf("\nValue : %d", value_in_cents1( Nickel ));
    printf("\nValue : %d", value_in_cents1( Dime ));
    printf("\nValue : %d", value_in_cents1( Quarter ));
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

int main() {
	printf("\n\nFunction: playWithTypes");
	playWithTypes();

	printf("\n\nFunction: playWithSum");
	playWithSum();

	printf("\n\nFunction: playWithArrays");
	playWithArrays();

	printf("\n\nFunction: playWithArraysAgain");
	playWithArraysAgain();

	printf("\n\nFunction: play_with_coins");
	play_with_coins();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

