
___________________________________________________________________________________

DAY 01
___________________________________________________________________________________

	ENVIRONMENT SETUP
		Please Setup Rust Programming Compilers

	REVISION ASSIGNMENT:
		Practice And Experiment With Code Examples Done Till Now In Class

	READING ASSIGNMENT IN C:
		Chapter 02: Types, Operators and Expressions
			The C Programming Language, 2nd Edition, By Kernighm and Ritchie

	READING ASSIGNMENT IN RUST:
		RUST READING MATERIAL:
			Reference Book:
				Rust Book https://doc.rust-lang.org/stable/book/

		Reading Assignment:
			Rust Concepts
				Variables and Mutability
				Data Types
				Functions
				Control Flows
				https://doc.rust-lang.org/stable/book/ch01-00-getting-started.html
				https://doc.rust-lang.org/stable/book/ch03-00-common-programming-concepts.html

			Rust Naming Convention
				https://rust-lang.github.io/api-guidelines/naming.html

	READING ASSIGNMENT FOR CURIOUS LEANERS:
			Dead Code Security Flaw
				https://www.sei.cmu.edu/library/unused-code-a-hidden-time-bomb/

___________________________________________________________________________________

DAY 02
___________________________________________________________________________________

___________________________________________________________________________________

DAY 03
___________________________________________________________________________________

___________________________________________________________________________________

DAY 04
___________________________________________________________________________________

___________________________________________________________________________________

DAY 05
___________________________________________________________________________________

___________________________________________________________________________________

DAY 06
___________________________________________________________________________________

___________________________________________________________________________________

DAY 07
___________________________________________________________________________________


